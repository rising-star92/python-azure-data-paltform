from typing import Union
from types import FunctionType

def find_pre_process_function(data_provider: str, table_name: str
                              ) -> Union[None, FunctionType]:
    return
