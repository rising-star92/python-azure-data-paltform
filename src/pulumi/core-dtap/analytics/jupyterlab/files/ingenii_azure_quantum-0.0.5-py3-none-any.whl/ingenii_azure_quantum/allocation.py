from azure.quantum import Workspace
from azure.quantum.optimization import Problem, ProblemType, \
    SimulatedAnnealing, Solver, Term
from itertools import combinations
from typing import List, Union

from .utils import submit_job

def add_terms_weight_variance_cost(weights: List[int], nb_containers: int
    ) -> List[Term]:
    """
    Add to the cost function Terms to minimise the weight variance between the
    containers

    Parameters
    ----------
    weights : List[int]
        The list of weights to be allocated
    nb_containers : int
        The number of containers to allocate between

    Returns
    -------
    List[Term]
        The terms to add to the cost function
    """
    target_weight = sum(weights) / nb_containers
    nb_weights = len(weights)

    # Treat weights in this format:
    # 1  5  9  7  3  - 1  5  9  7  3  - 1   5   9   7   3
    # W0 W1 W2 W3 W4   W5 W6 W7 W8 W9   W10 W11 W12 W13 W14 

    return [
        term
        for i in range(nb_containers)
        for j, w in enumerate(weights, start=i*nb_weights)
        for term in (
            # -1*Wi*target_weight.xi -2Wi^2.xi (weight variance cost + duplicate weight cost)
            Term(w=-2*w*target_weight - 2*w*w, indices=[j]),
            # Wi^3.xi^2 + Wi^2.xi^2 (weight variance cost + duplicate weight cost)
            Term(w=2*w*w, indices=[j, j])
        )
    ] + [
        Term(
            w=2*weights[c[0]]*weights[c[1]],
            indices=[i*nb_weights + c[0], i*nb_weights + c[1]]
        ) # 2*Wi*Wj (weight variance cost)
        for i in range(nb_containers)
        for c in combinations(range(nb_weights), 2)
    ]

def add_terms_duplicate_weight_cost(weights: List[int], nb_containers: int
    ) -> List[Term]:
    """
    Add to the cost function Terms to avoid allocating the same weight to
    different containers

    Parameters
    ----------
    weights : List[int]
        The list of weights to be allocated
    nb_containers : int
        The number of containers to allocate between

    Returns
    -------
    List[Term]
        The terms to add to the cost function
    """
    # The following is integrated into add_terms_weight_variance_cost to reduce
    # the number of Terms and speed-up Terms generation
    # for c in combinations(range(start, end+1), 1):
    #     w = container_weights[c[0]][0]
    #     i1 = container_weights[c[0]][1]
    #     terms.append(Term(w=w*w, indices=[i1,i1]))              # Wi^2

    # 2.w^2.x_i.x_j terms

    # The following is integrated into add_terms_weight_variance_cost to reduce
    # the number of Terms and speed-up Terms generation
    # # for c in combinations(range(start, end+1), 1):
    #     w = container_weights[c[0]][0]
    #     i1 = container_weights[c[0]][1]
    #     terms.append(Term(w=-2*w*w, indices=[i1]))              # -2*Wi^2

    nb_weights = len(weights)

    return [
        # Treat weights in this format:
        # 1  1  1 - 5  5  5 - 9  9  9 - 7  7  7 - 3  3  3
        # W0 W5 W10 W1 W6 W11 W2 W7 W12 W3 W8 W13 W4 W9 W14
        Term(
            w=2*weights[i]*weights[i],
            indices=[i + c[0]*nb_weights, i + c[1]*nb_weights]
        ) # Term(w=2*Wm^2, [m,n])
        for i in range(nb_weights)
        for c in combinations(range(nb_containers), 2)
    ] + [
        Term(w=weight*weight, indices=[]) # w^2 term
        for weight in weights
    ]

def create_terms_for_container_weights(
    weights: List[int], nb_containers: int, problem_type: int
    ) -> List[Term]:
    """
    Create the Terms for the cost function to allocate the weights

    Parameters
    ----------
    weights : List[int]
        The weights to be allocated
    nb_containers : int
        The number of containers to allocate between
    problem_type : int
        The type of the problem, drawn from the ProblemType class

    Returns
    -------
    List[Term]
        The terms to use as a cost function
    """
    if problem_type == ProblemType.ising:
        # Terms are symmetrical, so only pass the minimum required
        return [
            Term(c = w_i * w_j, indices = [i, j])
            for i, w_i in enumerate(weights)
            for j, w_j in enumerate(weights[i+1:], start=i+1)
        ]

    # PUBO problem
    return \
        add_terms_weight_variance_cost(weights, nb_containers) + \
        add_terms_duplicate_weight_cost(weights, nb_containers)

def parse_allocations(result: dict, weights: List[int],
                      nb_containers: int, problem_type: int) -> None:
    """
    Parse the result of the allocation, adding objects to more easily use it
    container_to_weight_id: dictionary where the key is the container ID, and
        value is a list of the indexes of the weights allocated to it
    container_to_weight: As above, but the values are a list of the weight
        values themselves instead of the indexes

    Parameters
    ----------
    result : dict
        Result dictionary obtained from azure.quantum.Job.get_results()
    weights : List[int]
        The weights to allocate
    nb_containers : int
        The number of containers to allocate between
    problem_type : int
        The type of the problem, drawn from the ProblemType class
    """
    nb_weights = len(weights)
    container_to_weight_id = result["container_to_weight_id"] = {
        i: [] for i in range(nb_containers)
    }
    container_to_weight = result["container_to_weight"] = {
        i: [] for i in range(nb_containers)
    }

    if not result.get("configuration"):
        return

    for key, alloc in result["configuration"].items():
        key = int(key)

        if problem_type in (ProblemType.ising, ProblemType.ising_grouped):
            # 1 is allocated to the first container, -1 to the second
            container_id = {1: 0, -1: 1}[alloc]
            container_to_weight_id[container_id].append(key)
            container_to_weight[container_id].append(weights[key])
        else:
            if alloc != 1:
                continue
            container_id = key // nb_weights
            weight_id = key % nb_weights
            container_to_weight_id[container_id].append(weight_id)
            container_to_weight[container_id].append(weights[weight_id])

def visualize_allocation_result(result: dict) -> None:
    """
    Given the parsed result, print some useful information

    Parameters
    ----------
    result : dict
        The parsed result, having been through the parse_allocations function
    """

    if result.get("configuration"):
        for i in sorted(result["container_to_weight_id"].keys()):
            print(
                f"Container {i}: " +
                "\t" + str(result["container_to_weight_id"][i]) + " - " +
                str(sum(result["container_to_weight"][i]))
            )
    else:
        print("No Configuration")
    
    if "cost" in result:
        print(f"Cost: {result['cost']}")
    else:
        print("No Cost")

    if "parameters" in result:
        print(f"Parameters: {result['parameters']}")
    else:
        print("No Parameter")

def allocate_weights(
        workspace: Workspace,
        weights: List[int], nb_containers: int,
        approach_type: Solver = SimulatedAnnealing,
        problem_type: Union[int, None] = None,
        **kwargs) -> dict:
    """
    Given a list of weight values and the number of containers to allocate them
    between, use Azure Quantum solvers to allocate the weights evenly

    Parameters
    ----------
    workspace : Workspace
        The object to connect to the Azure Quantum Workspace
    weights : List[int]
        A list of the weight values to allocate
    nb_containers : int
        The number of containers to allocate between
    approach_type : Solver, optional
        The azure.quantum.optimization.Solver to use, by default
        SimulatedAnnealing
    problem_type : Union[int, None], optional
        The problem type this should be considered from the ProblemType class,
        by default None
    **kwargs : dict
        Any parameters you want to pass to the Solver

    Returns
    -------
    dict
        The result of azure.quantum.Job.get_results(), that has been enhanced
        by parse_allocations
    """
    print("Total Weight:", sum(weights))
    print("Equal weight distribution:", sum(weights) / nb_containers)

    if problem_type is None:
        if nb_containers == 2:
            problem_type = ProblemType.ising
        else:
            problem_type = ProblemType.pubo

    # Create the Terms for this list of container_weights:
    terms = create_terms_for_container_weights(
        weights, nb_containers, problem_type)

    # Create the Problem to submit to the solver:
    problem_name = \
        f"Allocating {str(len(weights))} weights between " \
        f"{str(nb_containers)} containers ({len(terms):,} terms)"

    problem = Problem(name=problem_name, problem_type=problem_type, terms=terms)

    results = submit_job(workspace, problem, approach_type, **kwargs)

    # Update the results object with the allocations
    parse_allocations(results, weights, nb_containers, problem_type)
    
    return results
