from azure.quantum import Workspace
from azure.quantum.optimization import Problem, ProblemType, \
    SimulatedAnnealing, Solver, Term
from typing import List, Tuple

from .utils import submit_job

def number_nodes_and_max_cost(cost_matrix: List[List[int]]) -> Tuple[int, int]:
    """
    From the cost matrix, find the number of nodes and the maximum cost of any
    move between two nodes

    Parameters
    ----------
    cost_matrix : List[List[int]]
        The matrix of costs between each node

    Returns
    -------
    Tuple[int, int]
        The number of nodes, and the maximum cost
    """
    nb_nodes = len(cost_matrix)

    max_cost = 0
    for node_costs in cost_matrix:
        for each_cost in node_costs:
            if each_cost > max_cost:
                max_cost = each_cost
    
    return nb_nodes, max_cost

def create_terms(cost_matrix: List[List[int]], alpha: float, beta: float,
                 gamma: float, delta: float, epsilon: float,
                 nb_nodes: int=None, max_cost: int=None,
                 ) -> List[Term]:
    """
    Create the terms for the solver to use

    Parameters
    ----------
    cost_matrix : List[List[int]]
        The matrix of costs between each node
    alpha : float
        Penalty weight: cost of travelling between nodes
    beta : float
        Constraint weight: salesman can be at one node at a time
    gamma : float
        Constraint weight: salesman must be somewhere
    delta : float
        Penalty weight: must not visit the same node twice
    epsilon : float
        Penalty weight: start and end at the same node
    nb_nodes : int, optional
        Number of nodes, by default None. If not passed will be calculated
    max_cost : int, optional
        The maximum cost between any two nodes, by default None. If not passed
        will be calculated

    Returns
    -------
    List[Term]
        The list of Term objects for the solver
    """

    if nb_nodes is None or max_cost is None:
        nb_nodes, max_cost = number_nodes_and_max_cost(cost_matrix)

    # Terms will contain the weighting terms for the trips
    return [
        ##### Cost of traveling between nodes
        # Assign a weight to every possible trip from node i to node j for each trip 
        # 'alpha' allows us to tune the weights between the penalties 
        Term(
            c = alpha * cost_matrix[i][j], # Element of the cost matrix
            indices = [i + (nb_nodes * k), j + (nb_nodes * (k + 1))] # +1 to denote dependence on next location
        )
        for k in range(nb_nodes) # For each trip
        for i in range(nb_nodes) # For each origin node
        for j in range(nb_nodes) # For each destination node
    ] + [
        ##### Constraint: Location constraint - salesperson can only be at 1 node at a time.
        # 'beta' allows us to tune the weights between the penalties 
        Term(
            c = int(beta * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
            indices = [i + nb_nodes * l, j + nb_nodes * l]
        )
        for l in range(nb_nodes + 1) # The total number of nodes that are visited over the route (+1 because returning to starting node)
        for i in range(nb_nodes) # For each origin node
        for j in range(nb_nodes) # For each destination node
        if i < j # i<j because we don't want to penalize twice // i==j is forbidden (above)
    ] + [
        ##### Constraint: Location constraint - encourage the salesperson to be 'somewhere' otherwise all x_k might be 0 (for example).
        # 'gamma' allows us to tune the weights between the penalties 
        Term(
            c = int(-1 * gamma * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
            indices = [v]   
        )
        for v in range((nb_nodes + 1) * nb_nodes) # Select variable (v represents a node before/after any trip)
    ] + [
        ##### Penalty for traveling to the same node again --- (in the last step we can travel without penalties (this is to make it easier to specify an end node =) ))
        # 'delta' allows us to tune the weights between the penalties 
        Term(
            c = int(delta * max_cost), # assign a weight penalty dependent on maximum distance from the cost matrix elements
            indices = [p, f]   
        )
        for p in range((nb_nodes + 1) * nb_nodes) # This selects a present node x: 'p' for present    
        for f in range(p + nb_nodes, nb_nodes * (nb_nodes), nb_nodes) # This selects the same node x but after upcoming trips: 'f' for future
    ] + [
        ##### Begin at x0
        # 'epsilon' allows us to tune the weights between the penalties 
        Term(
            c = int(-1 * epsilon * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
            indices = [0]   
        ), 
        ##### End at x0
        Term(
            c = int(-1 * epsilon * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
            indices = [nb_nodes * nb_nodes]   
        ) 
    ]

def parse_path(result: dict, cost_matrix: List[List[int]], nb_nodes: int):
    """
    Parse the result found, adding to the 'result' dictionary a more easily
    understood 'path_route' object, and the 'cost' of the result

    Parameters
    ----------
    result : dict
        The raw result obtained from the solver
    cost_matrix : List[List[int]]
        The cost matrix of the problem
    nb_nodes : int
        The number of nodes in the path
    """
    ##### Read the results returned by the solver - need to make the solution readable

    ##### Read the return result (dictionary) from the solver and sort it
    parsed_config = sorted([int(k) for k, v in result["configuration"].items() if v == 1])

    ##### Create the route
    path_route = result["path_route"] = [
        {
            "node_id": node_index % nb_nodes,
            "time_step": node_index // nb_nodes,
        }
        for node_index in parsed_config
    ]

    ###### Calculate the total cost of the route the salesperson made (can be in time (minutes) or in distance (km))
    result["cost"] = sum([
        cost_matrix[node1["node_id"]][node2["node_id"]]
        for node1, node2 in zip(path_route[:-1], path_route[1:])
    ])

def validate_path(results: dict,  nb_nodes: int) -> bool:
    """
    Validate that the produced path is valid

    Parameters
    ----------
    results : dict
        The results obtained from the solver
    nb_nodes : int
        The number of nodes in the path

    Returns
    -------
    bool
        Whether the result is valid
    """
    ##### Check whether the solution satisfies the optimization constraints
    path_route = results["path_route"]

    is_valid = True
    errors = []

    ##### Check if the number of travels is equal to the number of nodes + 1 (for returning home)
    if len(path_route) != nb_nodes + 1:
        errors.append("This solution is not valid - Number of nodes visited invalid!")
        is_valid = False

    ##### Check if the nodes are different (except start/end node)
    past_nodes = set()
    for node in path_route[:-1]: # Start to second last node must all be different - skip last node so - 1
        if node["node_id"] in past_nodes:
            errors.append("This solution is not valid - Traveled to a non-starting node more than once")
            is_valid = False
        past_nodes.add(node["node_id"])

    ##### Check if the end node is same as the start node
    if path_route[0]["node_id"] != path_route[-1]["node_id"]:
        errors.append(
            f"This solution is not valid - Start node "
            f"{path_route[0]['node_id']} is not equal to end node "
            f"{path_route[-1]['node_id']}"
        )
        is_valid = False

    if errors:
        for error in errors:
            print(error)
    else:
        print("This solution is valid")
    return is_valid

def find_route(
        workspace: Workspace,
        cost_matrix: List[List[int]],
        alpha: float=1, beta: float=2, gamma: float=1.65,
        delta: float=2, epsilon: float=10,
        approach_type: Solver = SimulatedAnnealing,
        **kwargs) -> Tuple[dict, bool]:
    """
    From the cost matrix, find a suitable route

    Parameters
    ----------
    workspace : Workspace
        The object to connect to the Azure Quantum Workspace
    cost_matrix : List[List[int]]
        The matrix of costs between each of the points. Each sub-lists
        corresponds to one origin node
    alpha : float, optional
        Penalty weight: cost of travelling between nodes, by default 1
    beta : float, optional
        Constraint weight: salesman can be at one node at a time, by default 2
    gamma : float, optional
        Constraint weight: salesman must be somewhere, by default 1.65
    delta : float, optional
        Penalty weight: must not visit the same node twice, by default 2
    epsilon : float, optional
        Penalty weight: start and end at the same node, by default 10
    approach_type : Solver, optional
        The azure.quantum.optimization.Solver to use, by default
        SimulatedAnnealing
    **kwargs : dict
        Any parameters you want to pass to the Solver

    Returns
    -------
    dict, bool
        Details of the result found, and whether the result is valid
    """

    nb_nodes, max_cost = number_nodes_and_max_cost(cost_matrix)
    terms = create_terms(
        cost_matrix, alpha, beta, gamma, delta, epsilon,
        nb_nodes=nb_nodes, max_cost=max_cost
    )

    # Create the Problem to submit to the solver:
    problem_name = \
        f"Travelling salesperson problem for {nb_nodes}x{nb_nodes} matrix, " \
        f"max cost {max_cost} ({len(terms):,} terms)"

    problem = Problem(name=problem_name, problem_type=ProblemType.pubo, terms=terms)

    # Submit the problem and wait for the result
    results = submit_job(workspace, problem, approach_type, **kwargs)

    # Return the simulation result in a human understandable way
    parse_path(results, cost_matrix, nb_nodes)

    # Validate the result
    is_valid = validate_path(results, nb_nodes)

    return results, is_valid
