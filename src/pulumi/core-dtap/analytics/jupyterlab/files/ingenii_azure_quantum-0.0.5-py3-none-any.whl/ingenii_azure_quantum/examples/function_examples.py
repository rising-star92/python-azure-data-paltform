from azure.quantum.optimization import HardwarePlatform, ParallelTempering, \
    QuantumMonteCarlo, SimulatedAnnealing, Tabu

from ingenii_azure_quantum.allocation import allocate_weights, visualize_allocation_result
from ingenii_azure_quantum.scheduling import schedule_jobs
from ingenii_azure_quantum.traveling import find_route
from ingenii_azure_quantum.utils import get_workspace

workspace = get_workspace()

def allocation():

    # This array contains a list of the weights of the containers:
    weights = [3, 8, 3, 4, 1, 5, 2, 2, 7, 9, 5, 4, 8, 9, 4, 6, 8, 7, 6, 2, 2, 9, 4, 6, 3, 8, 5, 7, 2, 4, 9, 4]
    nb_containers = 5

    results = allocate_weights(workspace, weights, nb_containers, timeout=10)
    visualize_allocation_result(results)

    # From the results, let's extract the beta_start, beta_stop, restarts, and sweeps parameters selected
    beta_start = results["parameters"]["beta_start"]
    beta_stop = results["parameters"]["beta_stop"]
    restarts = results["parameters"]["restarts"]
    sweeps = results["parameters"]["sweeps"]

    # Now let's call the solver again, this time the parametrized version, using these parameters
    results = allocate_weights(
        workspace,
        weights, nb_containers, timeout=10, beta_start=beta_start,
        beta_stop=beta_stop, restarts=restarts, sweeps=sweeps)
    visualize_allocation_result(results)

    # Here's how we could experiment with different solvers from Microsoft

    results = allocate_weights(
        workspace,
        weights, nb_containers, approach_type=SimulatedAnnealing,
        timeout=5, platform=HardwarePlatform.FPGA)
    visualize_allocation_result(results)
    results = allocate_weights(
        workspace,
        weights, nb_containers, approach_type=Tabu, timeout=5)
    visualize_allocation_result(results)
    results = allocate_weights(
        workspace,
        weights, nb_containers, approach_type=ParallelTempering, timeout=60)
    visualize_allocation_result(results)
    results = allocate_weights(
        workspace,
        weights, nb_containers, approach_type=QuantumMonteCarlo)
    visualize_allocation_result(results)

    # And how we can submit the same jobs to solvers by third-party providers, such as 1QBit
    # Note: PathRelinkingSolver is only available if the 1QBit provider is enabled in your quantum workspace
    from azure.quantum.target.oneqbit import PathRelinkingSolver

    results = allocate_weights(
        workspace,
        weights, nb_containers, approach_type=PathRelinkingSolver)
    visualize_allocation_result(results)

def scheduling(visualise=False):

    # Set problem parameters
    ## Allowed time (jobs can only be scheduled below this limit)
    max_time = 21 

    ## Processing time for each operation
    ops_processing_time = {0: 2, 1: 1, 2: 3, 3: 2, 4: 2, 5: 3, 6: 1, 7: 2, 8: 3, 9: 2}

    ## Assignment of operations to jobs (job ID: [operation IDs])
    ### Operation IDs within a job must be in ascending order
    jobs_ops_map = {
        0: [0, 1, 2],   # Pay electricity bill
        1: [3, 4, 5],   # Plan camping trip
        2: [6, 7, 8, 9] # Book dentist appointment
    }

    ## Assignment of operations to machines
    ### Ten jobs, three machines
    machines_ops_map = {
        0: [0, 1, 3, 4, 6, 7],  # Operations 0, 1, 3, 4, 6 and 7 are assigned to machine 0 (the computer)
        1: [2, 5, 8],           # Operations 2, 5 and 8 are assigned to machine 1 (the printer)
        2: [9]                  # Operation 9 is assigned to machine 2 (the tooth floss)
    }

    result, is_valid = schedule_jobs(
        workspace, 
        jobs_ops_map, ops_processing_time, machines_ops_map,
        max_time=max_time, timeout=100
    )
    print(f"Valid result: {is_valid}")
    print(f"Operation start times: {result['operation_start_times']}")
    print(f"Job start times: {result['job_start_times']}")

    if not visualise:
        return

    import plotly.express as px

    nb_ops = len(ops_processing_time)

    # Graphics
    ops_to_machines = [None] * nb_ops
    for m, ops in machines_ops_map.items():
        for op in ops:
            ops_to_machines[op] = m

    ops = sorted(list(ops_processing_time.keys()))

    op_start_times = [
        result["operation_start_times"][op_id]
        for op_id in range(nb_ops)
    ]
    op_end_times = [
        start_time + ops_processing_time[i]
        for i, start_time in enumerate(op_start_times)
    ]

    # Create data frame
    df = {
        "Operation": ops,
        "Machine": ops_to_machines,
        "Start time": op_start_times,
        "Finish time": op_end_times,
        "delta": [ops_processing_time[i] for i in range(nb_ops)],
    }

    # Produce plot
    fig = px.timeline(df, title="Job Shop Schedule", color="Machine",
                      x_start="Start time", x_end="Finish time", y="Operation")

    fig.update_yaxes(autorange="reversed")
    fig.update_layout(
        font_family="Segoe UI",
        title_font_family="Segoe UI",
        width=800,
        height=800,
    )
    fig.layout.xaxis.type = "linear"
    fig.data[0].x = df["delta"]
    fig.update_layout(
        xaxis_title="Time step",
    )
    fig.update_yaxes(tick0=0, dtick=1)
    fig.update_xaxes(tick0=0, dtick=1)
    fig.show()

def travelling_salesperson():

    # Cost to travel between nodes -- note this matrix is not symmetric (traveling A->B is not same as B->A!)
    cost_matrix = [
        [1, 4, 7, 4, 3],
        [3, 3, 3, 1, 2],
        [2, 5, 2, 3, 1],
        [7, 8, 1, 3, 5],
        [3, 2, 1, 9, 8]
    ]
    # If you want to run with a randomised cost matrix, uncomment the below
    # import numpy as np
    # nb_nodes = 5
    # max_cost = 10
    # cost_matrix = np.random.randint(maxCost, size=(nb_nodes, nb_nodes))

    # Let's see the result using the default approach (approach_type=SimulatedAnnealing)
    result, is_valid = find_route(workspace, cost_matrix, timeout=120)   
    print(result)
    print(is_valid)

    # There are different approaches that can be used, returning varying quality of results at different speeds
    # Uncomment the different lines to test
    # result, is_valid = find_route(workspace, cost_matrix, approach_type=ParallelTempering, timeout=120)   
    # result, is_valid = find_route(workspace, cost_matrix, approach_type=Tabu, timeout=120)   
    # result, is_valid = find_route(workspace, cost_matrix, approach_type=QuantumMonteCarlo, sweeps=2, trotter_number=10, restarts=72, seed=22, beta_start=0.1, transverse_field_start=10, transverse_field_stop=0.1) # QMC is not available parameter-free yet
    # print(result)
    # print(is_valid)

# Uncomment to run the example
# allocation()
# scheduling()
# travelling_salesperson()
