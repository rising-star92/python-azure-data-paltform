from azure.quantum import Workspace
from azure.quantum.optimization import Problem, ProblemType, \
    SimulatedAnnealing, Term
from typing import List

from .utils import submit_job

def precedence_constraint(weight: float, max_time: int, jobs_ops_map: dict,
                          processing_time: dict) -> List[Term]:
    """
    Construct penalty terms for the precedence constraint.

    Keyword arguments:

    weight (float): Relative importance of this constraint
    max_time (int): Allowed time (jobs can only be scheduled below this limit)
    jobs_ops_map (dict): Map of jobs to operations {job: [operations]}
    processing_time (dict): Operation processing times
    """
    return [
        Term(c=weight, indices=[op1*max_time+t, op2*max_time+s])
        # Loop through all jobs:
        for ops in jobs_ops_map.values()
        # Loop through all pairs of operations in this job:
        for op1, op2 in zip(ops, ops[1:])
        for t in range(0, max_time)
        # Loop over times that would violate the constraint:
        for s in range(0, min(t + processing_time[op1], max_time))
    ]

def operation_once_constraint(weight: float, max_time: int, ops_jobs_map: dict
                              ) -> List[Term]:
    """
    Construct penalty terms for the operation once constraint.
    Penalty function is of form: 2xy - x - y + 1

    Keyword arguments:

    weight (float): Relative importance of this constraint
    T (int): Allowed time (jobs can only be scheduled below this limit)
    ops_jobs_map (dict): Map of operations to jobs {op: job}
    """
    return [
        # 2xy - x - y parts of the constraint function
        term
        # Loop through all operations
        for op in ops_jobs_map.keys()
        for t in range(max_time)
        for term in [
            # - x - y terms
            Term(c=weight*-1, indices=[op*max_time + t])
        ] + [
            Term(c=weight*2, indices=[op*max_time + t, op*max_time + s])
            # + 2xy term
            # Loop through all other start times for the same job to get the cross terms
            for s in range(t + 1, max_time)
        ]
    ] + [
        # + 1 term
        Term(c=weight*1, indices=[])
    ]

def no_overlap_constraint(weight: float, max_time: int, processing_time: dict,
                          ops_jobs_map: dict, machines_ops_map: dict
                          ) -> List[Term]:
    """
    Construct penalty terms for the no overlap constraint.

    Keyword arguments:

    weight (float): Relative importance of this constraint
    max_time (int): Allowed time (jobs can only be scheduled below this limit)
    processing_time (dict): Operation processing times
    ops_jobs_map (dict): Map of operations to jobs {op: job}
    machines_ops_map(dict): Mapping of operations to machines, e.g.:
        machines_ops_map = {
            0: [0,1],          # Operations 0 & 1 assigned to machine 0
            1: [2,3]           # Operations 2 & 3 assigned to machine 1
        }
    """
    return [
        term
        # For each machine
        for ops in machines_ops_map.values()
        # Loop over each operation i requiring this machine
        for i in ops
        # Loop over each operation k requiring this machine 
        for k in ops
        # Loop over simulation time
        for t in range(max_time)
        for term in [
            # t = s meaning two operations are scheduled to start at the same time on the same machine
            Term(c=weight*1, indices=[i*max_time+t, k*max_time+t])
        ] + [
            # Add penalty when operation runtimes overlap
            Term(c=weight*1, indices=[i*max_time+t, k*max_time+s])
            for s in range(t, min(t + processing_time[i], max_time))
        ] + [
            # If operations are in the same job, penalize for the extra time 0 -> t (operations scheduled out of order)
            Term(c=weight*1, indices=[i*max_time+t, k*max_time+s]) if i < k else Term(c=weight*1, indices=[i*max_time+s, k*max_time+t])
            for s in range(0, t)
            if ops_jobs_map[i] == ops_jobs_map[k]
        ]
        # When i != k (when scheduling two different operations)
        if i != k
    ]

def calculate_penalty(n_machines: int, t0: int, t: int):
    """
    Calculate the makespan penalty term

    Parameters
    ----------
    n_machines : int
        The number of machines to allocate between
    t0 : int
        The lower bound of the completion time
    t : int
        The time step of the completion of an operation

    Returns
    -------
    float
        The penalty for that particular time step
    """
    assert n_machines > 1 # Ensure you don't divide by 0
    return (n_machines**(t - t0) - 1)/float(n_machines - 1)

def determine_makespan_weight(
        n_machines: int, jobs_ops_map: dict, ops_processing_time: dict,
        max_time: int, lower_bound: int,
        alpha: float, beta: float, gamma: float) -> float:
    """
    Determine an appropriate makespan penalty weighting based on the weighting
    for the other penalties

    Parameters
    ----------
    n_machines : int
        The number of machines we are allocating between
    jobs_ops_map : dict
        Dictionary of jobs and their associated operations
    ops_processing_time : dict
        Dictionary of the operation ID to their processing times
    max_time : int
        The maximum possible time that the schedule can take
    lower_bound : int
        The shortest possible time the solution could take
    alpha : float
        Penalty weight: Precedence constraint
    beta : float
        Penalty weight: Operation once constraint
    gamma : float
        Penalty weight: No overlap constraint

    Returns
    -------
    float
        The new calculated weight for the makespan penalty
    """
    # Find the last completion time, i.e. what if the longest last operation
    # was scheduled at the last possible moment
    # 0-ordered, so need to -1
    max_completion_time = max_time - 1 + max([
        ops_processing_time[jobs[-1]] for jobs in jobs_ops_map.values()
    ])

    penalty = calculate_penalty(n_machines, lower_bound, max_completion_time)

    new_delta = 1 / (n_machines * penalty)

    # Make this 1/5 of the average of the other weights
    new_delta *= (sum([alpha, beta, gamma]) / 3) / 5

    return new_delta

def makespan_objective(weight: float, max_time: int, ops_processing_time: dict,
                       jobs_ops_map: dict, m_count: int, lower_bound: int
                       ) -> List[Term]:
    """
    Construct makespan minimization terms.

    Keyword arguments:

    weight (float): Relative importance of this constraint
    max_time (int): Allowed time (jobs can only be scheduled below this limit)
    ops_processing_time (dict): Operation processing times
    jobs_ops_map (dict): Map of jobs to operations {job: [operations]}
    m_count (int): Number of machines
    lower_bound: The minimum time that the solution could be completed in
    """
    return [
        Term(
            c=weight*(calculate_penalty(m_count, lower_bound, t)),
            indices=[(job[-1])*max_time + (t - ops_processing_time[job[-1]])]
        )
        # Loop through the final operation of each job
        for job in jobs_ops_map.values()
        # Loop through each time step the operation could be completion at
        for t in range(lower_bound + 1, max_time + ops_processing_time[job[-1]])
    ]

def process_config(jobs_ops_map: dict, machines_ops_map: dict,
                   processing_time: dict, T: int) -> None:
    """
    Process & validate problem parameters (config) and generate inverse dict of operations to jobs.

    Keyword arguments:
    
    jobs_ops_map (dict): Map of jobs to operations {job: [operations]}
    machines_ops_map(dict): Mapping of operations to machines, e.g.:
        machines_ops_map = {
            0: [0,1],          # Operations 0 & 1 assigned to machine 0
            1: [2,3]           # Operations 2 & 3 assigned to machine 1
        }
    processing_time (dict): Operation processing times
    T (int): Allowed time (jobs can only be scheduled below this limit)
    """

    # Problem cannot take longer to complete than all operations executed sequentially
    ## Sum all operation processing times to calculate the maximum makespan
    T = min(sum(processing_time.values()), T) 

    # Ensure operation assignments to machines are sorted in ascending order
    for m, ops in machines_ops_map.items():
        machines_ops_map[m] = sorted(ops)
    ops_jobs_map = {}

    for job, ops in jobs_ops_map.items():
        # Fail if operation IDs within a job are out of order
        assert (ops == sorted(ops)), f"Operation IDs within a job must be in ascending order. Job was: {job}: {ops}"

        for op in ops:
            # Fail if there are duplicate operation IDs
            assert (op not in ops_jobs_map.keys()), f"Operation IDs must be unique. Duplicate ID was: {op}"
            ops_jobs_map[op] = job

    return ops_jobs_map, T

def print_problem_details(ops_jobs_map: dict, processing_time: dict,
                          machines_ops_map: dict):
    """
    Print problem details e.g. operation runtimes and machine assignments.        
    
    Keyword arguments:
    ops_jobs_map (dict): Map of operations to jobs {operation: job}
    processing_time (dict): Operation processing times
    machines_ops_map(dict): Mapping of machines to operations
    """

    machines = [None] * len(ops_jobs_map)

    for m, ops in machines_ops_map.items():
        for op in ops:
          machines[op] = m
    
    print(f"           Job ID: {list(ops_jobs_map.values())}")
    print(f"     Operation ID: {list(ops_jobs_map.keys())}")
    print(f"Operation runtime: {list(processing_time.values())}")
    print(f" Assigned machine: {machines}")
    print()
    
def parse_scheduling(result: dict, jobs_ops_map: dict, max_time: int) -> None:
    """
    Parse the result of the scheduling, adding objects to more easily use it.
    Keys of the 'result' dictionary are the IDs all the possible points that
    the jobs could be started, effectively a (number of operations) x (maximum time)
    matrix. As such, when the value is 1 (ID // max_time) gives which operation
    this point belongs to, and the remainder (ID % max_time) shows which column
    on this 'row' the operation is set to start.

    Parameters
    ----------
    result: dict
        The resulting configuration
    jobs_ops_map : dict
        The dictionary showing the jobs and the associated operations
    max_time: int
        The maximum possible time that the schedule can take, which contributes
        to defining the size of the solution space
    """
    op_start_times = result["operation_start_times"] = {
        int(key) // max_time: int(key) % max_time
        for key, val in result["configuration"].items()
        if val == 1
    }
    result["job_start_times"] = {
        job: [op_start_times[op] for op in ops]
        for job, ops in jobs_ops_map.items()
    }

def check_precedence(op_start_times: dict, ops_processing_time: dict,
                     jobs_ops_map: dict) -> bool:
    """
    Check if the solution violates the precedence constraint.
    Returns True if the constraint is violated.       

    Parameters
    ----------
    op_start_times : dict
        Dictionary of the operation ID to their start times
    ops_processing_time : dict
        Dictionary of the operation ID to their processing times
    jobs_ops_map : dict
        Dictionary of jobs and their associated operations

    Returns
    -------
    bool
        True if the check is violated
    """

    for jobs in jobs_ops_map.values():
        for op1, op2 in zip(jobs, jobs[1:]):
            if op_start_times[op1] + ops_processing_time[op1] > op_start_times[op2]:
                return True
    return False
    
def check_operation_once(configuration: dict, max_time: int) -> bool:
    """
    Check if the solution violates the operation once constraint.
    Returns True if the constraint is violated.  

    Parameters
    ----------
    configuration : dict
        The raw configuration of the result
    max_time : int
        The maximum possible time that the schedule can take, which contributes
        to defining the size of the solution space

    Returns
    -------
    bool
        True if the check is violated
    """

    allocated_operations = [
        int(key) // max_time
        for key, value in configuration.items()
        if value == 1
    ]

    # Check if operation allocated twice
    if len(allocated_operations) != len(set(allocated_operations)):
        return True
    # Check all operations have been allocated
    if len(allocated_operations) * max_time != len(configuration.keys()):
        return True

    return False

def check_no_overlap(op_start_times: dict, machines_ops_map: dict,
                     ops_processing_time: dict) -> bool:
    """
    Check if the solution violates the no overlap constraint.
    Returns True if the constraint is violated.       

    Parameters
    ----------
    op_start_times : dict
        Dictionary of the operation ID to their start times
    machines_ops_map : dict
        Dictionary of the machine ID and the operations associated
    ops_processing_time : dict
        Dictionary of the operation ID to their processing times

    Returns
    -------
    bool
        True if the check is violated
    """

    # For each machine
    for ops in machines_ops_map.values():
        machine_start_times = [op_start_times[i] for i in ops]

        # Two operations start at the same time on the same machine
        if len(machine_start_times) != len(set(machine_start_times)):
            return True
        
        # Sort the operation IDs based on the machine start times
        ops_ids_sorted = [op for _, op in sorted(zip(machine_start_times, ops))]
        
        # # There is overlap in the runtimes of two operations assigned to the same machine
        for op1, op2 in zip(ops_ids_sorted, ops_ids_sorted[1:]):
            if op_start_times[op1] + ops_processing_time[op1] > op_start_times[op2]:
                return True

    return False

def validate_schedule(result: dict, machines_ops_map: dict,
                      ops_processing_time: dict, jobs_ops_map: dict,
                      max_time: int) -> bool:
    """
    Check that solution has not violated any constraints. 
    Returns True if the solution is valid.  

    Parameters
    ----------
    result : dict
        Details of the result found, including the parsed objects
    machines_ops_map : dict
        Dictionary of the machine ID and the operations associated
    ops_processing_time : dict
        Dictionary of the operation ID to their processing times
    jobs_ops_map : dict
        Dictionary of jobs and their associated operations
    max_time : int
        The maximum possible time that the schedule can take, which contributes
        to defining the size of the solution space

    Returns
    ----------
    bool
        Whether the solution is valid
    """

    # Check if constraints are violated
    precedence_violated = check_precedence(
        result["operation_start_times"], ops_processing_time, jobs_ops_map)
    operation_once_violated = check_operation_once(
        result["configuration"], max_time)
    no_overlap_violated = check_no_overlap(
        result["operation_start_times"], machines_ops_map, ops_processing_time)
    
    if any([precedence_violated, operation_once_violated, no_overlap_violated]):
        print("Solution not valid. Details:")
        print(f"\tPrecedence constraint violated: {precedence_violated}")
        print(f"\tOperation once constraint violated: {operation_once_violated}")
        print(f"\tNo overlap constraint violated: {no_overlap_violated}\n")
        return False
    else:
        print("Solution is valid.\n")
        return True

def schedule_jobs(
    workspace: Workspace,
    jobs_ops_map: dict, ops_processing_time: dict, machines_ops_map: dict,
    max_time: float=None,
    alpha: float=1, beta: float=1, gamma: float=1, delta: float=0.00000005,
    auto_makespan_weight: bool = False,
    approach_type=SimulatedAnnealing, **kwargs) -> dict:
    """
    From the job definition, create a schedule

    Parameters
    ----------
    workspace : Workspace
        The object to connect to the Azure Quantum Workspace
    jobs_ops_map : dict
        Map of jobs to operations {job: [operations]}
    ops_processing_time : dict
        Operation processing times {operation: time}
    machines_ops_map : dict
        Mapping of operations to machines, e.g.:
        machines_ops_map = {
            0: [0,1],          # Operations 0 & 1 assigned to machine 0
            1: [2,3]           # Operations 2 & 3 assigned to machine 1
        }
    max_time : float, optional
        The maximum time the final schedule can take, by default None
    alpha : float, optional
        Penalty weight: Precedence constraint, by default 1
    beta : float, optional
        Penalty weight: Operation once constraint, by default 1
    gamma : float, optional
        Penalty weight: No overlap constraint, by default 1
    delta : float, optional
        Penalty weight: Makespan minimization (objective function), by default 0.00000005
    auto_makespan_weight : bool, optional
        Whether to automatically determine delta, the weight allocated to the
        makespan penalty, by default False
    approach_type : Solver, optional
        The azure.quantum.optimization.Solver to use, by default
        SimulatedAnnealing
    **kwargs : dict
        Any parameters you want to pass to the Solver
    
    Returns
    ----------
    dict, bool
        Details of the result found, and whether the result is valid
    """
    longest_time = sum(ops_processing_time.values())
    if max_time:
        max_time = min(longest_time, max_time)
    else:
        max_time = longest_time
    
    ## Inverse mapping of jobs to operations
    ops_jobs_map, max_time = process_config(
        jobs_ops_map, machines_ops_map, ops_processing_time, max_time)

    lower_bound = max([
        sum([ops_processing_time[i] for i in job])
        for job in jobs_ops_map.values()
    ])
    n_machines = len(machines_ops_map)

    if auto_makespan_weight:
        delta = determine_makespan_weight(
            n_machines, jobs_ops_map, ops_processing_time, max_time, lower_bound,
            alpha, beta, gamma)

    terms = \
        precedence_constraint(
            alpha, max_time, jobs_ops_map, ops_processing_time) + \
        operation_once_constraint(
            beta, max_time, ops_jobs_map) + \
        no_overlap_constraint(
            gamma, max_time, ops_processing_time, ops_jobs_map, machines_ops_map) + \
        makespan_objective(
            delta, max_time, ops_processing_time, jobs_ops_map, n_machines, lower_bound)

    # Problem type is PUBO in this instance. You could also have chosen to represent the problem in Ising form.
    problem = Problem(name="Scheduling jobs", problem_type=ProblemType.pubo, terms=terms)

    print_problem_details(ops_jobs_map, ops_processing_time, machines_ops_map)

    result = submit_job(workspace, problem, approach_type, **kwargs)

    # Update the results object with the schedule in a more usable form
    parse_scheduling(result, jobs_ops_map, max_time)
    
    is_valid = validate_schedule(result, machines_ops_map, ops_processing_time,
                                 jobs_ops_map, max_time)

    return result, is_valid
