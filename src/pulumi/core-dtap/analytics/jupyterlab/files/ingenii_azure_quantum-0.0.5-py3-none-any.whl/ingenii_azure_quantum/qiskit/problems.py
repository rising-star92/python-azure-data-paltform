from qiskit.opflow import PauliSumOp, PauliOp
from qiskit_nature.drivers import Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
import qiskit_nature.problems.sampling.protein_folding as pf
from typing import List, Union

def protein_folding_problem(
        main_chain: str, side_chains: Union[List[str], None]=None, 
        interaction: pf.Interaction=pf.RandomInteraction(),
        penalty_back: int=10, penalty_chiral: int=10, penalty_1: int=10
    ) -> Union[PauliSumOp, PauliOp]:
    """
    Generate the problem using the Qiskit structure

    Parameters
    ----------
    main_chain : str
        Main, linear chain of ammino acids
    side_chains : Union[List[str], None], optional
        Any side chains from this main chain, by default None
    interaction : pf.Interaction, optional
        _description_, by default pf.RandomInteraction()
    penalty_back : int, optional
        A penalty parameter used to penalize turns along the same axis. This
        term is used to eliminate sequences where the same axis is chosen twice
        in a row. In this way we do not allow for a chain to fold back into
        itself. By default 10
    penalty_chiral : int, optional
        A penalty parameter used to impose the right chirality, by default 10
    penalty_1 : int, optional
        A penalty parameter used to penalize local overlap between beads within a nearest neighbor contact, by default 10
    
    Returns
    -------
    Union[PauliSumOp, PauliOp]
        The determined qubit operators
    """

    # Default is to have no side chains
    side_chains = side_chains or [""] * len(main_chain)

    # To ensure that all physical constraints are respected we introduce penalty functions
    penalty_terms = pf.PenaltyParameters(penalty_chiral, penalty_back, penalty_1)

    # Based on the main chain and possible side chains we define the peptide object that includes all the structural information of the modeled system.
    peptide = pf.Peptide(main_chain, side_chains)

    # Based on the defined peptide, the interaction (contact map) and the penalty terms we defined for our model we define the protein folding problem that returns qubit operators
    protein_folding_problem = pf.ProteinFoldingProblem(peptide, interaction, penalty_terms)

    return protein_folding_problem.qubit_op()

def electronic_structure_problem(
        molecule: Molecule, basis: str="sto3g",
        driver_type: str=ElectronicStructureDriverType.PYSCF
    ) -> ElectronicStructureProblem:
    """
    Given the molecule, construct the electronic structure problem

    Parameters
    ----------
    molecule : Molecule
        The molecule to investigate
    basis : str, optional
        The basis set, by default "sto3g"
    driver_type : str, optional
        The type of driver used, by default ElectronicStructureDriverType.PYSCF

    Returns
    -------
    ElectronicStructureProblem
        The constructed problem to be solved
    """

    driver = ElectronicStructureMoleculeDriver(
        molecule, basis=basis, driver_type=driver_type
    )

    return ElectronicStructureProblem(driver)