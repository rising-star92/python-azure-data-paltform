from azure.quantum import Workspace
from azure.quantum.optimization import Solver
from azure.quantum.qiskit import AzureQuantumProvider
from os import environ

def get_workspace(
    subscription_id: str=None, resource_group: str=None,
    location: str=None, name: str=None
) -> Workspace:
    """
    Get the connection to the Azure Quantum Workspace

    Parameters
    ----------
    subscription_id : str, optional
        The subscription ID, by default None
    resource_group : str, optional
        The resource group name, by default None
    location : str, optional
        The location, e.g. 'eastus', by default None
    name : str, optional
        The workspace name, by default None

    Returns
    -------
    Workspace
        The Azure Quantum Workspace
    """
    return Workspace(
        subscription_id=subscription_id or environ["WORKSPACE_SUBSCRIPTION_ID"],
        resource_group=resource_group or environ["WORKSPACE_RESOURCE_GROUP"],
        location=location or environ["WORKSPACE_LOCATION"],
        name=name or environ["WORKSPACE_NAME"],
    )

def get_qiskit_provider(
    subscription_id: str=None, resource_group: str=None,
    location: str=None, name: str=None
) -> AzureQuantumProvider:
    """
    Get the connection to the Azure Quantum Workspace in a way that Qiskit understands

    Parameters
    ----------
    subscription_id : str, optional
        The subscription ID, by default None
    resource_group : str, optional
        The resource group name, by default None
    location : str, optional
        The location, e.g. 'eastus', by default None
    name : str, optional
        The workspace name, by default None

    Returns
    -------
    AzureQuantumProvider
        The connection to the Azure Quantum Workspace
    """
    return AzureQuantumProvider(workspace=get_workspace(
        subscription_id=subscription_id, resource_group=resource_group,
        location=location, name=name,
    ))

def submit_job(workspace: Workspace, problem: int, approach_type: Solver, **kwargs) -> dict:
    """
    Submit a job and sequentially wait for the result

    Parameters
    ----------
    workspace : Workspace
        The object to connect to the Azure Quantum Workspace
    problem : int
        The problem type this should be considered from the ProblemType class
    approach_type : Solver
        The azure.quantum.optimization.Solver to use

    Returns
    -------
    dict
        The job results
    """

    approach = approach_type(workspace, **kwargs)

    # Optimize the problem
    print("Optimizing with:", approach.name)
    job = approach.submit(problem)
    job.wait_until_completed()
    duration = job.details.end_execution_time - job.details.begin_execution_time

    print("Execution duration:", duration)
    print("Job ID", job.id, job.details.status.lower())

    # First use the job id to view the parameters selected by the parameter free solver
    return workspace.get_job(job.id).get_results()
