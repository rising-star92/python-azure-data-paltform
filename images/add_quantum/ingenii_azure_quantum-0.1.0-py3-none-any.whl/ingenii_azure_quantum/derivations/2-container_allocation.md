# Allocation: 2-containers

This notebook is adapted from the 'ship loading' example provided by Azure Quantum, which follows a sample shipping company that wants to balance the loads of container ships at port. In this particular derivation we construct an Ising-problem, a particular optimization formulation which applies when we are allocating between two containers.

## The Problem
The notebook we adapt from describes a problem where ships are being loaded, but to generalise: we have a series of weights that we want to distribute evenly between two containers. 

This problem is known as the Number partitioning problem and is NP-complete. It is however relatively straightforward to apply Quantum Inspired Optimization (QIO) to it to generate a good solution.

## What does it mean to Optimize?
We're using Quantum-Inspired Optimization to solve this problem - but what does that actually mean?

In our case, optimize means "to find a solution with minimal cost" - which is exactly what the Solvers in Azure Quantum do. They take a representation of a difficult problem and apply techniques from physics to find a solution with the least cost.

> Note that solvers can be applied to very difficult problems where it's infeasible to confirm whether the solution found is the best solution that exists. So keep in mind that there may be better solutions than those returned by the solvers.

The solvers in Azure Quantum expect a `Binary Optimization Problem`, which is a problem expressed in the following (simplified) format:
$$  H = \Large\sum_{i} w_{i}x_{i} + \sum_{i,j} w_{i,j}x_{i}x_{j} $$
$$
x_{i} \in \left\{
        \begin{array}{ll}
            0 & \quad \\
            1 & \quad
        \end{array}
    \right.
\text{or}\quad
x_{i} \in \left\{
        \begin{array}{ll}
            1 & \quad \\
            -1 & \quad
        \end{array}
    \right.
$$

That is, a summation that is composed of weights ${w}$, and binary variables ${x_i}$. Let's explore how you formulate such a problem.

## Understanding the Problem
In the number partitioning problem, we have a set ${W}$ of weights which we would like to partition into two sets: ${W_a}$ and ${W_b}$ (weights on the containers, ${a}$ and ${b}$). In this section, our goal will be to develop a representation of the problem that we can provide to the QIO solver.

## Breaking down the Problem
Let's start by coming up with an equation for the weight of a given container, which is the sum of all the weights in the container. This is expressed in the below equation, where ${w_i}$ is the individual weight:

$$ \Large\sum_{i} w_{i} $$

Ideally, we'd like a solution where the weight difference between the containers is as small as possible. This is expressed by the following expression:

$$ H = \Large\sum_{i \in A} w_i - \Large\sum_{i \in B} w_i $$

If the value of ${H}$ is zero, we know the containers are equally loaded.

Next, we'll introduce a variable, ${x_i}$, to represent whether an individual weight ${i}$ is assigned to container ${a}$ or container ${b}$. Because we can assign the weight ${i}$ to either container, the variable ${x_i}$ can be take on two different values - which makes it a `binary` variable. For convenience, we'll say the two values it can take on are ${1}$ and ${-1}$: ${1}$ will represent that the weight is placed on container ${a}$, and ${-1}$ will represent that the weight is placed on container ${b}$.

> Because of our choice to make ${i}$ be either ${1}$ or ${-1}$ this type of problem is called an `Ising` problem. If we were assigning to more than two containers we would need to to formulate this problem differently - see the multi-container allocation derivation.

By introducing this variable ${x_i}$ to the previous equation, it can be simplified to:
$$ H = \Large\sum_{i \in A \cup B} w_ix_i $$

where 
$$ x_i = \begin{cases} +1 & \textrm{if   }i \in A \\ -1 & \textrm{if   }i \in B \end{cases} $$

The function ${H}$ will be called our `cost function` as it describes the cost of a given solution.

> The letter ${H}$ is traditionally used to represent a cost function and is also referred to as a `Hamiltonian` in a nod towards the quantum mechanical roots of Quantum-Inspired Optimization techniques.

## The final model
There's one last change we need to make before we can solve our problem. If we look at our cost function ${H}$ there's a flaw: the solution with the _least_ cost is to simply assign all weights to container ${b}$ by setting all ${x_i}={-1}$ - that's not right! To fix this we'll take a simple step - we'll square the right hand side of the equation so that it cannot be negative:

$$ H^{2} = \Large(\sum_{i \in A \cup B} w_{i} x_{i})^{2} $$

This is somewhat arbitrary, but it yields a cost function with the right properties:
- If all the weights are in one container, the function is at its highest value - reflecting that this is the least optimal solution
- If the containers are perfectly balanced, the value of the summation inside the square is ${0}$ - the function is at its lowest value
- In this case, we don't care about the actual value of ${H}$, just that it's as small as possible.

Next, let's express this problem in Python and solve it for a few cases.

## Turning the Cost function into a series of Terms in Python

For submitting problems to Azure Quantumm we must provide the cost function as a series of `azure.quantum.optimization.Term` objects. For the above cost function, this means creating a term for each possible value of $w_{i}$, and since the sum is squared we actually need to generate a `Term` for each _conbination_ of weights:

```python
terms = [
    Term(c = w_i * w_j, indices = [i, j])
    for i, w_i in enumerate(weights)
    for j, w_j in enumerate(weights)
    if i != j # We can skip where i == j as these are constant terms
]
```

## Improving the Cost Function
The cost function we've built works well so far, but on closer inspection you'll note that there are essentially duplicated terms that result from having squared the right hand side of the equation. Since $w_{i}$ and $w_{j}$ represent the same list of weights, if the indices are swapped this represents the same combination; i.e. `i=1, j=2` is the same as `i=2, j=1`. This duplication encodes the exact same information in our cost function. 

However, because we don't actually care about the value of the cost function (just the shape), we can omit these terms too by a slight modification to our cost function:

$$ H^2 = \Large(\sum_{i<j} w_{i} x_{i})^2 $$

In code, this means a small modification to the number of terms we create:
```python
terms = [
    Term(c = w_i * w_j, indices = [i, j])
    for i, w_i in enumerate(weights)
    for j, w_j in enumerate(weights[i+1:], start=i+1)
]
```

This creates half as many terms, speeding up finding the solution, and is the approach implemented in this package. This reveals an important fact about using QIO solvers: it is often possible (and neccesary) to optimize the cost function in order to generate more optimal solutions more quickly.
