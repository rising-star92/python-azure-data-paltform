from abc import ABC, abstractmethod
from azure.quantum import Workspace
from os import environ

class BaseAlgorithm(ABC):
    
    @property
    def workspace(self):
        return self._workspace

    @workspace.setter
    def workspace(self, value: Workspace):
        self._workspace = value

    @property
    def verbose(self):
        return self._verbose

    @verbose.setter
    def verbose(self, value: bool):
        self._verbose = value

    @abstractmethod
    def run(self):
        pass

    def __init__(self):
    
        self._workspace = None
        self._verbose = None

        self.description = None
        self.required_parameters = {}
        self.optional_parameters = {}
        self.example_parameters = {}

    def set_workspace(
            self, subscription_id: str=None, resource_group: str=None,
            location: str=None, name: str=None
        ) -> Workspace:
        """
        Get the connection to the Azure Quantum Workspace

        Parameters
        ----------
        subscription_id : str, optional
            The subscription ID, by default None
        resource_group : str, optional
            The resource group name, by default None
        location : str, optional
            The location, e.g. 'eastus', by default None
        name : str, optional
            The workspace name, by default None

        """
        self.workspace = Workspace(
            subscription_id=subscription_id or environ["WORKSPACE_SUBSCRIPTION_ID"],
            resource_group=resource_group or environ["WORKSPACE_RESOURCE_GROUP"],
            location=location or environ["WORKSPACE_LOCATION"],
            name=name or environ["WORKSPACE_NAME"],
        )
    