from .azure import AzureAlgorithm

__all__ = [
    "AzureAlgorithm",
]
