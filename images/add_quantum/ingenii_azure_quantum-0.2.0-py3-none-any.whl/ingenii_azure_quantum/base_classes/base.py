from abc import ABC, abstractmethod
from azure.quantum import Workspace
from os import getenv

from ingenii_azure_quantum.credential import HostedIngeniiChainedCredential

INGENII_HOSTED_ENVIRONMENT = bool(int(getenv("INGENII_HOSTED_ENVIRONMENT", "0")))

class ConfigurationException(Exception):
    ...

class BaseAlgorithm(ABC):
    
    @property
    def workspace(self):
        return self._workspace

    @workspace.setter
    def workspace(self, value: Workspace):
        self._workspace = value

    @property
    def verbose(self):
        return self._verbose

    @verbose.setter
    def verbose(self, value: bool):
        self._verbose = value

    @abstractmethod
    def run(self):
        pass

    def __init__(self):
    
        self._workspace = None
        self._verbose = None

        self.description = None
        self.required_parameters = {}
        self.optional_parameters = {}
        self.example_parameters = {}

    def set_workspace(
            self, subscription_id: str=None, resource_group: str=None,
            location: str=None, name: str=None, credential: object=None,
        ) -> Workspace:
        """
        Get the connection to the Azure Quantum Workspace

        Parameters
        ----------
        subscription_id : str, optional
            The subscription ID, by default None
        resource_group : str, optional
            The resource group name, by default None
        location : str, optional
            The location, e.g. 'eastus', by default None
        name : str, optional
            The workspace name, by default None

        """
        subscription_id = subscription_id or getenv("WORKSPACE_SUBSCRIPTION_ID")
        resource_group=resource_group or getenv("WORKSPACE_RESOURCE_GROUP")
        location=location or getenv("WORKSPACE_LOCATION")
        name=name or getenv("WORKSPACE_NAME")

        unset = [
            k for k, v in {
                "Susbscription ID": subscription_id,
                "Resource Group Name": resource_group,
                "Location, e.g 'eastus'": location,
                "Workspace Name": name,
            }.items()
            if v is None
        ]
        if unset:
            if INGENII_HOSTED_ENVIRONMENT:
                message = \
                    "Workspace details not set: " + ", ".join(unset) + "! " + \
                    "Something is set incorrectly in the hosted " + \
                    "environment. Please raise a ticket with Ingenii for " + \
                    "this to be investigated."
                
            else:
                message = \
                    "Workspace details not set: " + ", ".join(unset) + "! " + \
                    "Either pass all details to the algorithm's " + \
                    "set_workspace() function or set the appropriate " + \
                    "environment variables."
            raise ConfigurationException(message)

        workspace_args = {
            "subscription_id": subscription_id,
            "resource_group": resource_group,
            "location": location,
            "name": name,
        }

        # If in the hosted environment, use the special credential
        if INGENII_HOSTED_ENVIRONMENT:
            workspace_args["credential"] = \
                credential or HostedIngeniiChainedCredential()

        self.workspace = Workspace(**workspace_args)
    