from abc import abstractmethod
from azure.quantum.optimization import Problem, Solver, Term
from typing import List

from ingenii_azure_quantum.base_classes.base import BaseAlgorithm

class AzureAlgorithm(BaseAlgorithm):

    @property
    def problem(self):
        return self._problem

    @problem.setter
    def problem(self, value: Problem):
        self._problem = value

    @property
    def problem_name(self):
        return self._problem_name

    @problem_name.setter
    def problem_name(self, value: str):
        self._problem_name = value

    @property
    def problem_type(self):
        return self._problem_type

    @problem_type.setter
    def problem_type(self, value: int):
        self._problem_type = value

    @property
    def solver(self):
        return self._solver

    @solver.setter
    def solver(self, value: Solver):
        self._solver = value

    @property
    def terms(self):
        return self._terms

    @terms.setter
    def terms(self, value: List[Term]):
        self._terms = value

    def __init__(self):
        super().__init__()

        self._parameters = {}
        self._problem = None
        self._problem_name = None
        self._problem_type = None
        self._solver =  None
        self._solver_parameters = {}
        self._terms = []

    @abstractmethod
    def generate_terms(self) -> List[Term]:
        ...

    def _submit(self, problem_name):

        """ Submit a job and sequentially wait for the result """
        if not self.terms:
            self.generate_terms()

        if not self.workspace:
            self.set_workspace()

        # Check that the chosen solver is available on the workspace
        available_targets = [
            target.name for target in self.workspace.get_targets()
        ]
        target_names = self.solver.target_names
        if not any([tn in available_targets for tn in target_names]):
            raise Exception("\n".join([
                f"Solver with target names {target_names} not available on workspace {self.workspace.name}!",
                f"Currently available targets: {available_targets}",
                f"You can enable any other providers and targets in the Azure Portal at https://portal.azure.com",
            ]))

        approach = self.solver(self.workspace, **self.solver_parameters)

        self.problem = Problem(
            name=problem_name,
            problem_type=self.problem_type,
            terms=self.terms,
        )

        # Optimize the problem
        if self.verbose:
            print("Optimizing with:", approach.name)
        job = approach.submit(self.problem)
        job.wait_until_completed()
        duration = job.details.end_execution_time - job.details.begin_execution_time

        if self.verbose:
            print("Execution duration:", duration)
            print("Job ID", job.id, job.details.status.lower())

        # First use the job id to view the parameters selected by the parameter free solver
        self.result = self.workspace.get_job(job.id).get_results()
