from azure.quantum.optimization import ProblemType, SimulatedAnnealing, \
    Solver, Term
from typing import Dict, List

from ingenii_azure_quantum.base_classes import AzureAlgorithm

class ScheduleJobsBetweenMachines(AzureAlgorithm):

    description = "Given jobs, each a list of operations, and the machines they "
    "need to be run on, generate the best schedule to complete these jobs in the shortest time possible"
    required_parameters = {
        "jobs_ops_map": "Map of jobs to operations by their IDs, e.g. {0: [0, 1], 1: [2, 3]}, job 0 has operations 0 and 1, and job 1 has operations 2 and 3",
        "ops_processing_time": "Operation processing times e.g. {0: 3, 1: 5}, operation 0 takes 3, 1 takes 5, etc.",
        "machines_ops_map": "Mapping of machines to operations by their IDs, e.g.{0: [0, 1], 1: [2, 3]} operations 0 & 1 assigned to machine 0, operations 2 & 3 assigned to machine 1",
    }
    optional_parameters = {
        "max_time": "float. The maximum time the final schedule can take.",
        "precedence_constraint_weight": "float, by default 1. The weighting to be given to the precedence constraint", 
        "operation_once_constraint_weight": "float, by default 1. The weighting to be given to the operation_once constraint", 
        "no_overlap_constraint_weight": "float, by default 1. The weighting to be given to the no overlap constraint", 
        "makespan_minimization_weight": "float, by default 0.00000005. The weighting to be given to the makespan minimization constraint", 
        "auto_makespan_weight": "bool, by default False. If enabled, the makespan_minimization_weight will be calculated based on the problem details and other weights",
        "problem_name": "str. The name of the problem for when this is submitted to the Azure Quantum Workspace",
        "solver": "azure.quantum.optimization.Solver, by default SimulatedAnnealing. The class of the solver to use from azure.quantum.optimization.",
        "**kwargs": "Any other parameters to pass to the solver",
    }
    example_parameters = {
        "jobs_ops_map": {
            0: [0, 1, 2],
            1: [3, 4, 5],
            2: [6, 7, 8, 9],
        },
        "ops_processing_time": {
            0: 2, 1: 1, 2: 3, 3: 2, 4: 2, 5: 3, 6: 1, 7: 2, 8: 3, 9: 2
        },
        "machines_ops_map": {
            0: [0, 1, 3, 4, 6, 7],
            1: [2, 5, 8],
            2: [9]
        },
        "max_time": 21,
    }

    @classmethod
    def __str__(cls):
        return "Ingenii Azure Quantum algorithm ScheduleJobsBetweenMachines"

    _jobs_ops_map = None

    @property
    def jobs_ops_map(self):
        return self._jobs_ops_map

    @jobs_ops_map.setter
    def jobs_ops_map(self, value: Dict[int, List[int]]):
        self._jobs_ops_map = value
        self.process_config()
        self.determine_makespan_weight()
        self.generate_terms()

    _ops_jobs_map =  None

    @property
    def ops_jobs_map(self):
        return self._ops_jobs_map

    @ops_jobs_map.setter
    def ops_jobs_map(self, value: Dict[int, List[int]]):
        self._ops_jobs_map = value

    _ops_processing_time = None

    @property
    def ops_processing_time(self):
        return self._ops_processing_time

    @ops_processing_time.setter
    def ops_processing_time(self, value: Dict[int, int]):
        self._ops_processing_time = value
        self.get_max_time()
        self.determine_makespan_weight()
        self.generate_terms()

    _machines_ops_map = None

    @property
    def machines_ops_map(self):
        return self._machines_ops_map

    @machines_ops_map.setter
    def machines_ops_map(self, value: Dict[int, List[int]]):
        self._machines_ops_map = value
        self.process_config()
        self.generate_terms()
    
    _max_time = None

    @property
    def max_time(self):
        return self._max_time

    @max_time.setter
    def max_time(self, value: int):
        self._max_time = value
        self.determine_makespan_weight()
        self.generate_terms()

    _precedence_constraint_weight = None

    @property
    def precedence_constraint_weight(self):
        return self._precedence_constraint_weight

    @precedence_constraint_weight.setter
    def precedence_constraint_weight(self, value: float):
        self._precedence_constraint_weight = value
        self.determine_makespan_weight()
        self.generate_terms()

    _operation_once_constraint_weight = None

    @property
    def operation_once_constraint_weight(self):
        return self._operation_once_constraint_weight

    @operation_once_constraint_weight.setter
    def operation_once_constraint_weight(self, value: float):
        self._operation_once_constraint_weight = value
        self.determine_makespan_weight()
        self.generate_terms()

    _no_overlap_constraint_weight = None

    @property
    def no_overlap_constraint_weight(self):
        return self._no_overlap_constraint_weight

    @no_overlap_constraint_weight.setter
    def no_overlap_constraint_weight(self, value: float):
        self._no_overlap_constraint_weight = value
        self.determine_makespan_weight()
        self.generate_terms()

    _makespan_minimization_weight = None

    @property
    def makespan_minimization_weight(self):
        return self._makespan_minimization_weight

    @makespan_minimization_weight.setter
    def makespan_minimization_weight(self, value: float):
        self._makespan_minimization_weight = value
        self.generate_terms()

    _auto_makespan_weight = None

    @property
    def auto_makespan_weight(self):
        return self._auto_makespan_weight

    @auto_makespan_weight.setter
    def auto_makespan_weight(self, value: bool):
        self._auto_makespan_weight = value
        if value:
            self.determine_makespan_weight()
            self.generate_terms()

    problem_type = ProblemType.pubo

    def __init__(self, 
        jobs_ops_map: dict, ops_processing_time: dict, machines_ops_map: dict,
        max_time: float=None,
        precedence_constraint_weight: float=1, 
        operation_once_constraint_weight: float=1,
        no_overlap_constraint_weight: float=1, 
        makespan_minimization_weight: float=0.00000005,
        auto_makespan_weight: bool=False,
        problem_name: str="",
        solver: Solver=SimulatedAnnealing, 
        **kwargs
    ):
        super().__init__()

        self.jobs_ops_map = jobs_ops_map
        self.ops_processing_time = ops_processing_time
        self.machines_ops_map = machines_ops_map

        self.max_time = max_time
        self.get_max_time()

        self.precedence_constraint_weight = precedence_constraint_weight
        self.operation_once_constraint_weight = operation_once_constraint_weight
        self.no_overlap_constraint_weight = no_overlap_constraint_weight
        self.makespan_minimization_weight = makespan_minimization_weight
        self.auto_makespan_weight = auto_makespan_weight

        self.problem_name = problem_name

        self.solver = solver
        self.solver_parameters = {
            **{"timeout": 100 },
            **kwargs
        }

    # --------------------------------------------------------------------------
    # Handle the configuration
    # --------------------------------------------------------------------------

    def process_config(self):
        """ Process & validate problem parameters (config) and generate inverse
        dict of operations to jobs """

        # Ensure operation assignments to machines are sorted in ascending order
        if self.machines_ops_map:
            for m, ops in self.machines_ops_map.items():
                self.machines_ops_map[m] = sorted(ops)

        if not self.jobs_ops_map:
            return
        ops_jobs_map = {}
        for job, ops in self.jobs_ops_map.items():
            # Fail if operation IDs within a job are out of order
            assert (ops == sorted(ops)), f"Operation IDs within a job must be in ascending order. Job was: {job}: {ops}"

            for op in ops:
                # Fail if there are duplicate operation IDs
                assert (op not in ops_jobs_map.keys()), f"Operation IDs must be unique. Duplicate ID was: {op}"
                ops_jobs_map[op] = job

        self.ops_jobs_map = ops_jobs_map

    def get_max_time(self):
        # Problem cannot take longer to complete than all operations executed sequentially
        ## Sum all operation processing times to calculate the maximum makespan
        longest_time = sum(self.ops_processing_time.values())
        if self.max_time:
            self.max_time = min(longest_time, self.max_time)
        else:
            self.max_time = longest_time

    # --------------------------------------------------------------------------
    # Generate the terms
    # --------------------------------------------------------------------------

    def precedence_constraint(self) -> List[Term]:
        """ Construct penalty terms for the precedence constraint """
        return [
            Term(
                c=self.precedence_constraint_weight,
                indices=[op1*self.max_time+t, op2*self.max_time+s]
            )
            # Loop through all jobs:
            for ops in self.jobs_ops_map.values()
            # Loop through all pairs of operations in this job:
            for op1, op2 in zip(ops, ops[1:])
            for t in range(0, self.max_time)
            # Loop over times that would violate the constraint:
            for s in range(0, min(t + self.ops_processing_time[op1], self.max_time))
        ]

    def operation_once_constraint(self) -> List[Term]:
        """ Construct penalty terms for the operation once constraint. Penalty
        function is of form: 2xy - x - y + 1 """
        return [
            # 2xy - x - y parts of the constraint function
            term
            # Loop through all operations
            for op in self.ops_jobs_map.keys()
            for t in range(self.max_time)
            for term in [
                # - x - y terms
                Term(
                    c=self.operation_once_constraint_weight*-1,
                    indices=[op*self.max_time + t]
                )
            ] + [
                Term(
                    c=self.operation_once_constraint_weight*2,
                    indices=[op*self.max_time + t, op*self.max_time + s]
                )
                # + 2xy term
                # Loop through all other start times for the same job to get the cross terms
                for s in range(t + 1, self.max_time)
            ]
        ] + [
            # + 1 term
            Term(c=self.operation_once_constraint_weight*1, indices=[])
        ]

    def no_overlap_constraint(self) -> List[Term]:
        """ Construct penalty terms for the no overlap constraint. """
        return [
            term
            # For each machine
            for ops in self.machines_ops_map.values()
            # Loop over each operation i requiring this machine
            for i in ops
            # Loop over each operation k requiring this machine 
            for k in ops
            # Loop over simulation time
            for t in range(self.max_time)
            for term in [
                # t = s meaning two operations are scheduled to start at the same time on the same machine
                Term(
                    c=self.no_overlap_constraint_weight*1,
                    indices=[i*self.max_time+t, k*self.max_time+t]
                )
            ] + [
                # Add penalty when operation runtimes overlap
                Term(
                    c=self.no_overlap_constraint_weight*1,
                    indices=[i*self.max_time+t, k*self.max_time+s]
                )
                for s in range(t, min(t + self.ops_processing_time[i], self.max_time))
            ] + [
                # If operations are in the same job, penalize for the extra time 0 -> t (operations scheduled out of order)
                Term(
                    c=self.no_overlap_constraint_weight*1,
                    indices=[i*self.max_time+t, k*self.max_time+s]
                )
                if i < k else 
                Term(
                    c=self.no_overlap_constraint_weight*1,
                    indices=[i*self.max_time+s, k*self.max_time+t]
                )
                for s in range(0, t)
                if self.ops_jobs_map[i] == self.ops_jobs_map[k]
            ]
            # When i != k (when scheduling two different operations)
            if i != k
        ]
    
    def makespan_objective(self):
        """ Construct makespan minimization terms """

        return [
            Term(
                c=self.makespan_minimization_weight * self.calculate_penalty(t),
                indices=[(job[-1])*self.max_time + (t - self.ops_processing_time[job[-1]])]
            )
            # Loop through the final operation of each job
            for job in self.jobs_ops_map.values()
            # Loop through each time step the operation could be completion at
            for t in range(self.get_lower_bound() + 1, self.max_time + self.ops_processing_time[job[-1]])
        ]

    def generate_terms(self) -> List[Term]:

        if any([
            self.jobs_ops_map is None,
            self.ops_processing_time is None,
            self.machines_ops_map is None,
            self.max_time is None,
            self.precedence_constraint_weight is None,
            self.operation_once_constraint_weight is None,
            self.no_overlap_constraint_weight is None,
            self.makespan_minimization_weight is None,
        ]):
            return

        """ Generate all the problem terms """
        self.terms = \
            self.precedence_constraint() + \
            self.operation_once_constraint() + \
            self.no_overlap_constraint() + \
            self.makespan_objective()
    
    def get_lower_bound(self):
        """ Find the shortest amount of time it is possible to complete all jobs """
        return max([
            sum([self.ops_processing_time[i] for i in job])
            for job in self.jobs_ops_map.values()
        ])

    def calculate_penalty(self, time: int):
        """ Calculate the makespan penalty term for a particular time """

        lower_bound = self.get_lower_bound()
        n_machines = len(self.machines_ops_map)
        assert n_machines > 1 # Ensure you don't divide by 0
        return (n_machines**(time - lower_bound) - 1)/float(n_machines - 1)

    def determine_makespan_weight(self):
        """ Determine an appropriate makespan penalty weighting based on the
        weighting for the other penalties """
        if not self.auto_makespan_weight:
            return

        # Find the last completion time, i.e. what if the longest last operation
        # was scheduled at the last possible moment
        # 0-ordered, so need to -1
        max_completion_time = self.max_time - 1 + max([
            self.ops_processing_time[jobs[-1]]
            for jobs in self.jobs_ops_map.values()
        ])

        penalty = self.calculate_penalty(max_completion_time)
  
        n_machines = len(self.machines_ops_map)
        new_delta = 1 / (n_machines * penalty)

        # Make this 1/5 of the average of the other weights
        new_delta *= (
            sum([
                self.precedence_constraint_weight,
                self.operation_once_constraint_weight,
                self.no_overlap_constraint_weight
            ]) / 3
        ) / 5

        self.makespan_minimization_weight = new_delta

    # --------------------------------------------------------------------------
    # Parsing and checking the result
    # --------------------------------------------------------------------------

    def print_problem_details(self):
        """
        Print problem details e.g. operation runtimes and machine assignments.        
        
        Keyword arguments:
        ops_jobs_map (dict): Map of operations to jobs {operation: job}
        processing_time (dict): Operation processing times
        machines_ops_map(dict): Mapping of machines to operations
        """

        machines = [None] * len(self.ops_jobs_map)

        for m, ops in self.machines_ops_map.items():
            for op in ops:
                machines[op] = m
        
        print(f"           Job ID: {list(self.ops_jobs_map.values())}")
        print(f"     Operation ID: {list(self.ops_jobs_map.keys())}")
        print(f"Operation runtime: {list(self.ops_processing_time.values())}")
        print(f" Assigned machine: {machines}")
        print()
    
    def check_precedence(self) -> bool:
        """ Check if the solution violates the precedence constraint. Returns 
        True if the constraint is violated. """

        op_start_times = self.result["operation_start_times"]

        for jobs in self.jobs_ops_map.values():
            for op1, op2 in zip(jobs, jobs[1:]):
                if op_start_times[op1] + self.ops_processing_time[op1] > op_start_times[op2]:
                    return True
        return False
        
    def check_operation_once(self) -> bool:
        """ Check if the solution violates the operation once constraint.
        Returns True if the constraint is violated. """

        configuration = self.result["configuration"]
        allocated_operations = [
            int(key) // self.max_time
            for key, value in configuration.items()
            if value == 1
        ]

        # Check if operation allocated twice
        if len(allocated_operations) != len(set(allocated_operations)):
            return True
        # Check all operations have been allocated
        if len(allocated_operations) * self.max_time != len(configuration.keys()):
            return True

        return False

    def check_no_overlap(self) -> bool:
        """ Check if the solution violates the no overlap constraint. Returns
        True if the constraint is violated. """

        op_start_times = self.result["operation_start_times"]
        # For each machine
        for ops in self.machines_ops_map.values():
            machine_start_times = [op_start_times[i] for i in ops]

            # Two operations start at the same time on the same machine
            if len(machine_start_times) != len(set(machine_start_times)):
                return True
            
            # Sort the operation IDs based on the machine start times
            ops_ids_sorted = [op for _, op in sorted(zip(machine_start_times, ops))]
            
            # # There is overlap in the runtimes of two operations assigned to the same machine
            for op1, op2 in zip(ops_ids_sorted, ops_ids_sorted[1:]):
                if op_start_times[op1] + self.ops_processing_time[op1] > op_start_times[op2]:
                    return True

        return False

    def validate_schedule(self) -> bool:
        """ Check that solution has not violated any constraints. Returns True
        if the solution is valid. """

        # Check if constraints are violated
        precedence_violated = self.check_precedence()
        operation_once_violated = self.check_operation_once()
        no_overlap_violated = self.check_no_overlap()
        
        if any([precedence_violated, operation_once_violated, no_overlap_violated]):
            print("Solution not valid. Details:")
            print(f"\tPrecedence constraint violated: {precedence_violated}")
            print(f"\tOperation once constraint violated: {operation_once_violated}")
            print(f"\tNo overlap constraint violated: {no_overlap_violated}\n")
            self.result["valid"] = False
        else:
            print("Solution is valid.\n")
            self.result["valid"] = True

    def parse_scheduling(self):
        """
        Parse the result of the scheduling, adding objects to more easily use it.
        Keys of the 'result' dictionary are the IDs all the possible points that
        the jobs could be started, effectively a (number of operations) x (maximum time)
        matrix. As such, when the value is 1 (ID // max_time) gives which operation
        this point belongs to, and the remainder (ID % max_time) shows which column
        on this 'row' the operation is set to start.
        """
        op_start_times = self.result["operation_start_times"] = {
            int(key) // self.max_time: int(key) % self.max_time
            for key, val in self.result["configuration"].items()
            if val == 1
        }
        self.result["job_start_times"] = {
            job: [op_start_times[op] for op in ops]
            for job, ops in self.jobs_ops_map.items()
        }

        self.validate_schedule()

    def run(self):
        # workspace: Workspace,
        # jobs_ops_map: dict, ops_processing_time: dict, machines_ops_map: dict,
        # max_time: float=None,
        # alpha: float=1, beta: float=1, gamma: float=1, delta: float=0.00000005,
        # auto_makespan_weight: bool = False,
        # approach_type=SimulatedAnnealing, **kwargs) -> dict:

        if self.verbose:
            self.print_problem_details()

        if self.problem_name:
            problem_name = self.problem_name
        else:
            problem_name = \
                f"Finding best schedule for allocating jobs between machines"

        self._submit(problem_name=problem_name)

        # Update the results object with the schedule in a more usable form
        self.parse_scheduling()
        