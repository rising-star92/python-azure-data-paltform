from azure.identity import DeviceCodeCredential, SharedTokenCacheCredential, \
    TokenCachePersistenceOptions
from azure.quantum._authentication._chained import _ChainedTokenCredential
from os import getenv, path
from requests import post
from time import time
from typing import Any

config_path = getenv("AZURE_CONFIG_DIR", None) or path.expanduser(path.join("~", ".azure"))

class HostedIngeniiCredential(DeviceCodeCredential):

    _hosted_auth_url = getenv(
        "INGENII_HOSTED_AUTH_LAYER_URL", "https://hostedauth.ingenii.io"
    ) + "/aad_token"
    _auth0_token = getenv("AUTH0_ID_TOKEN")
    
    def __init__(self, **kwargs):

        # Matches the SharedTokenCacheCredential
        kwargs["cache_persistence_options"] = TokenCachePersistenceOptions(
            allow_unencrypted_storage=True
        )
        super(HostedIngeniiCredential, self).__init__(**kwargs)

    def _request_token(self, *scopes: str, **kwargs: Any) -> dict:

        request_time = int(time())

        ial_response = post(self._hosted_auth_url, json={
            "id_token": self._auth0_token,
            "scopes": list(scopes),
        }).json()

        self._cache.add(
            event={
                "client_id": ial_response["client_id"],
                "response": ial_response["response"],
                "scope": ial_response["response"]["scope"].split(),
                "token_endpoint": ial_response["token_endpoint"],
            },
            now=request_time,
        )

        return ial_response["response"]
        

class HostedIngeniiChainedCredential(_ChainedTokenCredential):

    def __init__(self):
        super(HostedIngeniiChainedCredential, self).__init__(
            SharedTokenCacheCredential(),
            HostedIngeniiCredential(),
        )
