from qiskit.algorithms.optimizers import COBYLA, Optimizer
from qiskit.algorithms import VQE
from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import RealAmplitudes
from qiskit.opflow import CVaRExpectation, PauliExpectation, PauliSumOp, PauliOp
from qiskit.utils import algorithm_globals
from qiskit_nature.algorithms import GroundStateEigensolver, QEOM, VQEUCCFactory
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.problems.second_quantization import BaseProblem
from typing import Union

from .base import QiskitAlgorithm

class VQEwithCVaRSolver(QiskitAlgorithm):

    @property
    def qubit_operator(self):
        return self._qubit_operator

    @qubit_operator.setter
    def qubit_operator(self, value: Union[PauliSumOp, PauliOp]):
        self._qubit_operator = value

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, value: Optimizer):
        self._optimizer = value

    @property
    def ansatz(self):
        return self._ansatz

    @ansatz.setter
    def ansatz(self, value: QuantumCircuit):
        self._ansatz = value

    @property
    def cvar_alpha(self):
        return self._cvar_alpha

    @cvar_alpha.setter
    def cvar_alpha(self, value: float):
        self._cvar_alpha = value

    def __init__(
            self,
            optimizer: Optimizer=COBYLA(maxiter=50),
            ansatz: QuantumCircuit=RealAmplitudes(reps=1),
            cvar_alpha: float=0.1,
            azure_backend_name: Union[str, None]=None,
            qiskit_backend: Union[str, None]=None,
            aer_default: str="aer_simulator",
            verbose: bool=False,
            **kwargs,
        ) -> dict:
        """
        Given the qubit operator, solve using Variational Quantum Eigensolver with
        Conditional Value at Risk (CVaR) expectation values

        Parameters
        ----------
        optimizer : Optimizer, optional
            The classical optimizer to use, by default COBYLA(maxiter=50)
        ansatz : QuantumCircuit, optional
            The variational ansatz to use, by default RealAmplitudes(reps=1)
        cvar_alpha : float, optional
            The CVaR_alpha objective to use, by default 0.1
        azure_quantum_provider : AzureQuantumProvider, optional
            The provider to connect to the Azure Quantum Workspace, by default None
        azure_backend_name : Union[str, None], optional
            The name of the backend to use in the Azure Quantum workspace, by
            default None. If not set, the qiskit_backend variable is considered 
        qiskit_backend : Union[str, None], optional
            The Qiskit backend to use, by default None. If azure_backend_name is
            not set then this is next to be used
        aer_default : str, by default "aer_simulator"
            The Aer backend to use, if azure_backend_name and qiskit_backend is not set
        verbose: bool, optional
            If set, give more information while solving problem
        **kwargs
            Anything else to pass when creating the quantum instance
        """
        super().__init__()

        self._qubit_operator = None
        self._optimizer = None
        self._ansatz = None
        self._cvar_alpha = None

        self.optimizer = optimizer
        self.ansatz = ansatz
        self.cvar_alpha = cvar_alpha

        self.set_quantum_instance(
            azure_backend_name=azure_backend_name,
            qiskit_backend=qiskit_backend,
            aer_default=aer_default,
            shots=8192,
            seed_transpiler=algorithm_globals.random_seed,
            seed_simulator=algorithm_globals.random_seed,
            **kwargs,
        )

        self.verbose = verbose

    def run(self):

        self.intermediate_results = []

        # Initialize VQE using CVaR
        cvar_exp = CVaRExpectation(self.cvar_alpha, PauliExpectation())
        vqe = VQE(
            expectation=cvar_exp,
            optimizer=self.optimizer,
            ansatz=self.ansatz,
            quantum_instance=self.quantum_instance,
            callback=self.store_intermediate_result,
        )

        # Get the result
        result = vqe.compute_minimum_eigenvalue(self.qubit_operator)

        self.result = {
            "result": result,
            "intermediate_results": self.intermediate_results
        }

class QEOMSolver(QiskitAlgorithm):

    @property
    def es_problem(self):
        return self._es_problem

    @es_problem.setter
    def es_problem(self, value: BaseProblem):
        self._es_problem = value

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, value: Optimizer):
        self._optimizer = value

    @property
    def qubit_converter(self):
        return self._qubit_converter

    @qubit_converter.setter
    def qubit_converter(self, value: QubitConverter):
        self._qubit_converter = value

    def __init__(
            self,
            optimizer: Optimizer=COBYLA(maxiter=20),
            qubit_converter: QubitConverter=QubitConverter(JordanWignerMapper()),
            azure_backend_name: Union[str, None]=None,
            qiskit_backend: Union[str, None]=None,
            aer_default: str="aer_simulator_statevector",
            verbose: bool=False,
            **kwargs,
        ) -> dict:
        """
        Solve a problem with the qEOM algorithm [arXiv preprint arXiv:1910.12890 (2019)]

        Parameters
        ----------
        optimizer : Optimizer, optional
            The classical optimizer to use, by default COBYLA(maxiter=20)
        qubit_converter : QubitConverter, optional
            The Qubit converter to understand the problem, by default
            QubitConverter(JordanWignerMapper())
        azure_quantum_provider : AzureQuantumProvider, optional
            The provider to connect to the Azure Quantum Workspace, by default None
        azure_backend_name : Union[str, None], optional
            The name of the backend to use in the Azure Quantum workspace, by
            default None. If not set, the qiskit_backend variable is considered 
        qiskit_backend : Union[str, None], optional
            The Qiskit backend to use, by default None. If azure_backend_name is
            not set then this is next to be used
        aer_default : str, by default "aer_simulator_statevector"
            The Aer backend to use, if azure_backend_name and qiskit_backend is not set
        verbose: bool, optional
            If set, give more information while solving problem
        **kwargs
            Anything else to pass when creating the quantum instance
        """
        super().__init__()

        self._es_problem = None
        self._optimizer = None
        self._qubit_converter = None

        self.optimizer = optimizer
        self.qubit_converter = qubit_converter

        self.set_quantum_instance(
            azure_backend_name=azure_backend_name,
            qiskit_backend=qiskit_backend,
            aer_default=aer_default,
            shots=8192,
            seed_transpiler=algorithm_globals.random_seed,
            seed_simulator=algorithm_globals.random_seed,
            **kwargs,
        )

        self.verbose = verbose

    def run(self):
        
        self.intermediate_results = []

        # This first part sets the ground state solver
        solver = VQEUCCFactory(
            self.quantum_instance,
            self.optimizer,
            callback=self.store_intermediate_result
        )
        gsc = GroundStateEigensolver(self.qubit_converter, solver)

        # The qEOM algorithm is instantiated with the chosen ground state solver
        qeom_excited_states_calculation = QEOM(gsc, "sd")

        self.result = {
            "result": qeom_excited_states_calculation.solve(self.es_problem),
            "intermediate_results": self.intermediate_results
        }
