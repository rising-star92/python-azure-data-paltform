from azure.quantum.qiskit import AzureQuantumProvider
from azure.quantum.target import Target
from qiskit import Aer
from qiskit.utils import QuantumInstance
from typing import Union

from ingenii_azure_quantum.base_classes.base import BaseAlgorithm

class QiskitAlgorithm(BaseAlgorithm):

    @property
    def workspace(self):
        return self._workspace

    @workspace.setter
    def workspace(self, value: AzureQuantumProvider):
        self._workspace = value
    
    @property
    def quantum_instance(self):
        return self._quantum_instance

    @quantum_instance.setter
    def quantum_instance(self, value: Union[Target, QuantumInstance]):
        self._quantum_instance = value
    
    def __init__(self):
        super().__init__()
    
        self._quantum_instance = None
        self._workspace = None

        self.intermediate_results = []

    def set_workspace(self, **kwargs):
        """ 
        Set the connection to the Azure Quantum Workspace in a way that Qiskit understands
        """
        super().set_workspace(**kwargs)
        self.workspace = AzureQuantumProvider(workspace=self.workspace)
    
    def set_quantum_instance(
            self,
            azure_backend_name: str=None,
            qiskit_backend: str=None,
            aer_default: str="aer_simulator",
            **kwargs
        ):
        """
        Find an appropriate quantum instances

        Parameters
        ----------
        azure_backend_name : str, optional
            First priority, by default None
        qiskit_backend : str, optional
            Second priority, by default None
        aer_default : str, optional
            Third priority, by default "aer_simulator"
        kwargs:
            Any other settings to pass to the QuantumInstance

        Returns
        -------
        QuantumInstance
            The quantum instance to use
        """
        if azure_backend_name:
            if self.workspace is None:
                self.set_workspace()
            self.quantum_instance = self.workspace.get_backend(azure_backend_name)
        else:
            self.quantum_instance = QuantumInstance(
                qiskit_backend or Aer.get_backend(aer_default),
                **kwargs
            )

    def store_intermediate_result(self, eval_count, parameters, mean, std):
        if self.verbose:
            print(f"Evaluation count: {eval_count}/{self.optimizer.settings['options']['maxiter']}")
        self.intermediate_results.append({
            "count": eval_count,
            "parameters": parameters,
            "mean": mean,
            "standard_deviation": std,
        })

class AzureQiskitAccess(QiskitAlgorithm):

    def run(self):
        raise Exception("This class is for accessing an Azure Quantum instance, and not as an algorithm itself. Nothing to run.")
