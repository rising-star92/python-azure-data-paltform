from qiskit_nature.drivers import Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
import qiskit_nature.problems.sampling.protein_folding as pf
from typing import List, Union

from .solvers import VQEwithCVaRSolver, QEOMSolver

class ProteinFoldingProblemVQEwithCVaR(VQEwithCVaRSolver):

    description = "Given a protein chain, determine the minimum energy conformation. Uses the VQE with CVaR solver"
    required_parameters = {
        "main_chain": "str. Main linear chain of ammino acids. Letter to use comes from IUPAC-IUB Commission on Biochemical Nomenclature (1972). “A one-letter notation for aminoacid sequences”. Pure and Applied Chemistry. 31 (4): 641-645. doi:10.1351/pac197231040639. PMID 5080161.",
    }
    optional_parameters = {
        "side_chains": "List[str], by default None. Any side chains from this main chain.",
        "interaction": "qiskit_nature.problems.sampling.protein_folding.Interaction, by default RandomInteraction(). Potential for the description of inter-residue contacts.",
        "penalty_chiral": "float, by default 10. A penalty parameter used to impose the right chirality.",
        "penalty_back": "float, by default 10. A penalty parameter used to penalize turns along the same axis. This term is used to eliminate sequences where the same axis is chosen twice in a row. In this way we do not allow for a chain to fold back into itself.",
        "penalty_1": "float, by default 10. A penalty parameter used to penalize local overlap between beads within a nearest neighbor contact.",
        "**kwargs": "Configuration for the VQE with CVar solver",
    }
    example_parameters = {
        "main_chain": "APRLRFY",
    }

    @property
    def main_chain(self):
        return self._main_chain

    @main_chain.setter
    def main_chain(self, value: str):
        self._main_chain = value
        self.generate_qubit_operator()

    @property
    def side_chains(self):
        return self._side_chains

    @side_chains.setter
    def side_chains(self, value: Union[List[str], None]):
        self._side_chains = value
        self.generate_qubit_operator()

    @property
    def interaction(self):
        return self._interaction

    @interaction.setter
    def interaction(self, value: pf.Interaction):
        self._interaction = value
        self.generate_qubit_operator()

    @property
    def penalty_chiral(self):
        return self._penalty_chiral

    @penalty_chiral.setter
    def penalty_chiral(self, value: float):
        self._penalty_chiral = value
        self.generate_qubit_operator()

    @property
    def penalty_back(self):
        return self._penalty_back

    @penalty_back.setter
    def penalty_back(self, value: float):
        self._penalty_back = value
        self.generate_qubit_operator()

    @property
    def penalty_1(self):
        return self._penalty_1

    @penalty_1.setter
    def penalty_1(self, value: float):
        self._penalty_1 = value
        self.generate_qubit_operator()

    def __init__(
            self,
            main_chain: str, side_chains: Union[List[str], None]=None, 
            interaction: pf.Interaction=pf.RandomInteraction(),
            penalty_chiral: float=10, penalty_back: float=10, penalty_1: float=10,
            **kwargs
        ):
        """ Generate the protein folding problem and initialise the solver """

        super().__init__(**kwargs)

        self._main_chain = None
        self._side_chains = None
        self._interaction = None
        self._penalty_chiral = None
        self._penalty_back = None
        self._penalty_1 = None

        self.main_chain = main_chain
        self.side_chains = side_chains
        self.interaction = interaction
        self.penalty_chiral = penalty_chiral
        self.penalty_back = penalty_back
        self.penalty_1 = penalty_1

    def generate_qubit_operator(self):

        if any([
            self.main_chain is None,
            self.interaction is None,
            self.penalty_chiral is None,
            self.penalty_back is None,
            self.penalty_1 is None,
        ]):
            return

        # Default is to have no side chains
        side_chains = self.side_chains or [""] * len(self.main_chain)

        # To ensure that all physical constraints are respected we introduce penalty functions
        penalty_terms = pf.PenaltyParameters(self.penalty_chiral, self.penalty_back, self.penalty_1)

        # Based on the main chain and possible side chains we define the peptide object that includes all the structural information of the modeled system.
        peptide = pf.Peptide(self.main_chain, side_chains)

        # Based on the defined peptide, the interaction (contact map) and the penalty terms we defined for our model we define the protein folding problem that returns qubit operators
        protein_folding_problem = pf.ProteinFoldingProblem(peptide, self.interaction, penalty_terms)

        self.qubit_operator = protein_folding_problem.qubit_op()


class ElectronicStructureProblemQEOM(QEOMSolver):

    description = "Given a molecule's details, compute the excited states of the corresponding molecular Hamiltonian. Uses the QEOMSolver"
    required_parameters = {
        "molecule": "qiskit_nature.drivers.Molecule. The molecule to investigate",
    }
    optional_parameters = {
        "basis": "str, by default 'sto3g'. The basis set",
        "driver_type": "str, by default qiskit_nature.drivers.second_quantization.ElectronicStructureDriverType.PYSCF. The type of driver used",
        "**kwargs": "Configuration for the QEOM solver",
    }
    example_parameters = {
        "molecule": Molecule(
            geometry=[["H", [0.0, 0.0, 0.0]], ["H", [0.0, 0.0, 0.735]]],
            charge=0, multiplicity=1
        )
    }

    @property
    def molecule(self):
        return self._molecule

    @molecule.setter
    def molecule(self, value: Molecule):
        self._molecule = value
        self.generate_es_problem()

    @property
    def basis(self):
        return self._basis

    @basis.setter
    def basis(self, value: str):
        self._basis = value
        self.generate_es_problem()

    @property
    def driver_type(self):
        return self._driver_type

    @driver_type.setter
    def driver_type(self, value: str):
        self._driver_type = value
        self.generate_es_problem()

    def __init__(
            self,
            molecule: Molecule, basis: str="sto3g",
            driver_type: str=ElectronicStructureDriverType.PYSCF,
            **kwargs,
        ):
        super().__init__(**kwargs)

        self._molecule = None
        self._basis = None
        self._driver_type = None

        self.molecule = molecule
        self.basis = basis
        self.driver_type = driver_type

    def generate_es_problem(self):
        """ Given the molecule, construct the electronic structure problem and initialise the solver """
        if any([
            self.molecule is None,
            self.basis is None,
            self.driver_type is None,
        ]):
            return

        driver = ElectronicStructureMoleculeDriver(
            self.molecule, basis=self.basis, driver_type=self.driver_type
        )

        self.es_problem = ElectronicStructureProblem(driver)
