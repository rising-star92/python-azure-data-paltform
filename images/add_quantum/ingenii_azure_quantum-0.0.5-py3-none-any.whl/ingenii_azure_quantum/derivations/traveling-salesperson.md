# Traveling Salesperson

## Introduction

The traveling salesperson problem is a well-known optimization problem in which the aim is to find a (near) optimal route through a network of nodes. This is not a straightforward problem to solve as the complexity grows exponentially with the number of nodes. Additionally, due to the rugged (non-convex) optimization space, it is difficult or even impossible to find an optimal route (global minimum/optimal solution) through a large network. Common solvers for these rugged problems are based on searches, which are implemented in these functions.

Imagine you have to calculate an optimal route for the salesperson over $N$ nodes (addresses) minimizing the traveling cost (time/distance/money/etc.).. There are a number of constraints which have to be satisfied by the salesperson:

1. The salesperson is required to visit each node. 
2. The salesperson may visit each node only once.s
3. The salesperson starts and finishes in the starting node (headquarters). 

For more information regarding the traveling salesperson problem, check out these links:

- [Introduction to binary optimization - Azure Quantum docs](https://docs.microsoft.com/en-us/azure/quantum/optimization-binary-optimization) 
- [Traveling salesperson problem - Wikipedia](https://en.wikipedia.org/wiki/Travelling_salesperson_problem)

> Please note this derivation is intended to demonstrate how to formulate the cost function for a well-understood problem mathematically and then map it to a binary QUBO/PUBO format. The Traveling Salesperson Problem is not a good example of a problem that scales well in this format, as detailed in [this paper](https://arxiv.org/abs/1702.06248).

## Defining a cost function: Minimizing the travel cost

The generated route should minimize the travel cost for the salesperson. We will first need to define the travel costs between the nodes and have a suitable mapping for the location of the salesperson. 

### 1. Defining the travel cost matrix

Consider a single trip for the salesperson, from one node to another node. They start at node $i$ and travel to node $j$, which requires $c(i,j)$ in travel costs. Here, $i$ denotes the origin node and $j$ denotes the destination node. To keep matters simple for now, both $i$ and $j$ can be any node in the set of $N$ nodes. 

$$ \text{The origin node } (\text{node } i) \text{ with } i \in \{0,N-1\}.$$
$$ \text{The destination node } (\text{node } j) \text{ with } j \in \{0,N-1\}.$$
$$ \text{Time traveling from } \text{node } i \text{ to } \text{node } j \text{ is } c_{i,j}.$$

The travel cost between two nodes can be written out for every $i$ and $j$, resulting in a travel cost matrix $C$ (linear algebra), shown below:

$$C = \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix}. $$

Here, we define the rows to be origin nodes and the columns to be destination nodes. 
For example, traveling from node 0 to node 1 is simply described by:

$$ C(0,1) = c_{0,1}. $$

The unit for the travel cost is arbitrary: it can be time, distance, money, or a combination of these and/or other factors.

### 2. Defining the location vectors

Now that the travel cost between two nodes has been formulated, a representation of the origin and destination nodes of the salesperson must be defined to specify which element of the matrix gives the associated travel cost. Note that this is still for a single trip. This is the same as saying "we need a way to select a row-column pair in the cost matrix", which can be done by multiplying the cost matrix with a vector from the left, and a vector from the right. The left vector will specify the origin node and the right vector the destination node. For brevity they'll be named the origin vector (left) and the destination vector (right).

Consider the example where the salesperson travels from node 1 to node 2:

$$ \text{Travel cost node 0 to node 1 }=  \begin{bmatrix} 1 & 0 & \dots & 0 \end{bmatrix} \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix} \begin{bmatrix} 0 \\ 1 \\ \vdots \\ 0 \end{bmatrix} = c_{0,1}.$$

> Please note that the salesperson can only visit one node at a time and that there is only one salesperson, thus the sum elements in the origin and destination vector must equal 1.

However, it is necessary to express these ideas in mathematical format that the solver understands. In the previous example the trip was hard-coded from node 1 to node 2, so let's generalize this from any origin node to any destination node:

$$ x_k \in \{0,1\} \text{ for } k \in \{0,2N-1\}, $$

$$ \text{Travel cost for single trip }=  \begin{bmatrix} x_0 & x_1 & \dots & x_{N-1} \end{bmatrix} \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix} \begin{bmatrix} x_{N} \\ x_{N+1}\\ \vdots \\ x_{2N-1} \end{bmatrix}. $$

The solver will determine which $x_k$ are given a value of 1 or 0 (this is the binary variable you are optimizing). If the value is 1, it means the salesperson is travelling between the corresponding origin and destination nodes. Correspondingly, if the value is 0 it means the salesperson is not originating from or traveling to that location.

> You may be wondering why the destination vector is indexed from $N+1$ to $2N$ (seperate variables). The reason for this is that otherwise, the solver would consider the left vector and the right vector equal. As as consequence, there would be an origin vector on both sides of the cost matrix, meaning the salesperson would remain at the origin node, which isn't allowed, and would count as visiting the same node more than once, which also isn't allowed. 

To summarize: for the salesperson to be at one node at a time, the sum of the vector elements for both the origin and destination vectors has to be 1.

$$ \text{Sum of the origin vector elements: }\sum_{k = 0}^{N-1} x_k = 1, $$ 
$$ \text{Sum of the destination vector elements: }\sum_{k = N}^{2N-1} x_k = 1.$$ 

### 3. Defining the travel costs for a route

To derive the cost function for a route through a network, you'll need a way to describe the 'total travel cost'. As you might expect, the total cost of a route through the network is the sum of the travel costs between the nodes (sum of the trips). Say you have a route ($R$) from node 1 to node 3 to node 2. The total cost of the route would then be: 

$$ \text{Cost of route: } R_{1-3-2} = c_{1,3} + c_{3,2}. $$

Note that for the second trip, the origin node is the same as the destination node of the previous trip. Knowing that the last destination equals the new origin is a useful property when reducing the number of variables the solver has to optimize for. Therefore these vectors can also be called the 'location' vectors. 

Recall that the costs can be expressed with linear algebra. Then the total cost of two trips is:

$$ \text{Cost of route } = \begin{bmatrix} x_0 & x_1 & \dots & x_{N-1} \end{bmatrix} \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix} \begin{bmatrix} x_{N} \\ x_{N+1}\\ \vdots \\ x_{2N-1} \end{bmatrix} + \begin{bmatrix} x_{N} & x_{N+1} & \dots & x_{2N-1} \end{bmatrix} \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix} \begin{bmatrix} x_{2N} \\ x_{2N+1}\\ \vdots \\ x_{3N-1} \end{bmatrix}.$$

Generalizing the small example to a route in which the salesperson visits all $N$ nodes and returns back to the starting location gives

$$\text{Travel cost of route } = \sum_{k=0}^{N-1} \left(  \begin{bmatrix} x_{Nk} & x_{Nk+1} & \dots & x_{Nk+N-1} \end{bmatrix} \begin{bmatrix} c_{0,0} & c_{0,1} & \dots & c_{0,N-1} \\ c_{1,0} & c_{1,1} & \dots & c_{1,N-1} \\ \vdots & \ddots & \ddots & \vdots \\ c_{N-1,0} & c_{N-1,1} & \dots & c_{N-1,N-1} \end{bmatrix} \begin{bmatrix} x_{N(k+1)} \\ x_{N(k+1)+1}\\ \vdots \\ x_{N(k+1)+N-1} \end{bmatrix} \right),$$

which can equivalently be written as:
 
$$\text{Travel cost of route} = \sum_{k=0}^{N-1}\sum_{i=0}^{N-1}\sum_{j=0}^{N-1} \left( x_{Nk+i}\cdot x_{N(k+1)+j}\cdot c_{i,j} \right).$$

Fantastic! A cost function to optimize for the salesperson's route has been found! Because you want to minimize (denoted by the 'min') the total travel cost with respect to the variables $x_k$ (given below the 'min'), you'll want to slightly adjust the model: 

$$\text{Travel cost of route} := \underset{x_0, x_1,\dots,x_{(N^2+2N)}}{min}\sum_{k=0}^{N-1}\sum_{i=0}^{N-1}\sum_{j=0}^{N-1} \left( x_{Nk+i}\cdot x_{N(k+1)+j}\cdot c_{i,j} \right).$$

### 4. Coding the cost function

For the solver to find a suitable route, you'll need to specify how it calculates the travel cost for that route. The solver requires you to define a cost term for each possible trip-origin-destination combination given by the variables $k,i,j$, respectively. As described by the cost function, this weighting term is simply the $c(i,j)$ element of the cost matrix. The solver will optimize for the $x$ variables of the location vectors.

```python
    ##### Cost of traveling between nodes
    # Assign a weight to every possible trip from node i to node j for each trip
    # 'alpha' allows us to tune the weights between the penalties 
    Term(
        c = alpha * cost_matrix[i][j], # Element of the cost matrix
        indices = [i + (nb_nodes * k), j + (nb_nodes * (k + 1))] # +1 to denote dependence on next location
    )
    for k in range(nb_nodes) # For each trip
    for i in range(nb_nodes) # For each origin node
    for j in range(nb_nodes) # For each destination node
```

## Defining optimization constraints: Penalizing invalid routes

The modeled cost function will allow you to find the cheapest route for the salesperson, however it does not include any information on invalid routes, so er need to add penalties for routes which the salesperson should not travel.

### Constraint 1: The salesperson may not be at more than one node at a time (no magic)

The salesperson can only be at one node at a time. In the defined cost function this constraint is not enforced, and thus the solver can return origin and location vectors for which the sum is larger than one. Such vectors represent invalid solutions, which we penalize by modifying the cost function. You can imagine the penalization of the cost function as reshaping/redesigning the rugged optimization landscape such that for invalid solutions the solver cannot find (local) minima. Invalid solutions should have such high cost that the solver is very unlikely to select them, but not so high as to block the solver from moving around that area of the cost function to find other, valid solutions. 

To ensure that the salesperson is only ever at a single location, before or after a trip, we must require that only one element in the origin or destination vector is equal to 1, with the rest being 0. One way of designing the constraint would be to look at the sum of elements of each location vector (the origin and destination vectors):

$$ \text{Location vector 0 (HQ)} : \text{ } \hspace{0.5cm}  x_0 + x_1 + \dots + x_{N-1} = 1, $$
$$ \text{Location vector 1} : \text{ } \hspace{0.5cm} x_{N} + x_{N+1} + \dots + x_{2N-1} = 1, $$
$$ \vdots $$
$$ \text{Location vector N (HQ)} : \text{ } \hspace{0.5cm} x_{N^2} + x_{N^2+1} + \dots + x_{N^2 + N-1} = 1. $$

Enforcing the constraint over all trips would then yield ($N+1$ because the salesperson returns to starting node):

$$ \text{For all locations: } \hspace{0.5cm}  x_0 + x_1 + \dots +  x_{N^2 + N-1} = N+1. $$
 
The equation above is a valid way to model the constraint. However, there is a downside to it as well: in this formulation individual locations are penalized but there is no penalty for being in two locations at once. To see this, take the following example:

$$
\text{ If the first } N + 1 \text{ values are all 1:}\\
x_0=1, x_{1}=1, \dots, x_{N}=1, \\
\text{ } \\
\text{ and all other } x \text{ values are 0:}\\
x_{N+1}=0, x_{N+2}=0, \dots, x_{N^2+N-1}=0, 
$$  

The constraint is satisfied but the salesperson is still at all nodes at once. Thus the derived equation is not specific enough to model the location constraint. 

Consider three nodes (a length-3 location vector): if the salesperson is at node 1, they cannot be at node 0 or node 2. If the salesperson is at node 0, they cannot be at node 1 or node 2. Instead of using a sum to express this, an equally valid way would be to use products. The product of elements in a location vector must always be zero, regardless of where the salesperson resides, because only one of the three $x$ values can take value 1 (denoting the salesperson being at that location). Therefore the constraint can also be expressed as: 
$$ x_0 \cdot x_1 = 0,$$
$$ x_0 \cdot x_2 = 0,$$ 
$$ x_1 \cdot x_2 = 0.$$

In this format the constraint is much more specific and stricter for the solver. As a result, the solver will provide solutions that do not violate this constraint. Note that we do not want to count combinations more than once, as this would lead to (assymmetries) inbalances in the cost function. We therefore exclude the reverse combinations:

$$ x_{1}\cdot x_{0}, $$
$$ x_{2}\cdot x_{0}, $$
$$ x_{2}\cdot x_{1}. $$

Generalizing the location constraint for a salesperson who passes through all nodes and returns back to the starting node ($N+1$ nodes in total, iterating over $l$):

$$ \sum_{l=0}^{N} \sum_{i=0}^{N-1} \sum_{j=0}^{N-1} x_{(i+Nl)} \cdot x_{(j+Nl)} = 0 \text{ with } \{ i,j | i<j \}  $$

```python
    # 'beta' allows us to tune the weights between the penalties 
    Term(
        c = int(beta * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
        indices = [i + nb_nodes * l, j + nb_nodes * l]
    )
    for l in range(nb_nodes + 1) # The total number of nodes that are visited over the route (+1 because returning to starting node)
    for i in range(nb_nodes) # For each origin node
    for j in range(nb_nodes) # For each destination node
    if i < j # i<j because we don't want to penalize twice // i==j is forbidden (above)
```

### Constraint 2: The salesperson must be somewhere, they can't disappear

Due to the first constraint, the salesperson is penalized for being in multiple nodes at once, but it is possible that the solver puts all all $x_k$ in a location vector equal to zero, meaning that the salesperson could be 'nowhere' after some trip.

> By looking at the code and previous sections you can come to the conclusion that the minimal cost is obtained by setting all $x_k$ to 0.

To encourage the salesperson to not disappear, it is necessary to reward them for being somewhere. Rewards can be assigned by incorporating negatively weighted terms to the cost function that decrease the cost function value for valid solutions of the optimization problem (remember we are minimizing the cost here, so reducing cost makes it more likely that a solution will be chosen). To demonstrate this point, take the following optimization problem:

$$\text{f(x)} := \underset{x_0, x_1, x_2}{min} x_0 + x_1 - x_2.$$ 
$$ \text{with } x_0, x_1, x_2 \in \{0,1\}$$

The minimum value for the example is attained for the solution $x_0$ = 0, $x_1$ = 0, $x_2$ = 1, with the optimal function value equal to -1. Here, the negatively weighted third term encourages $x_2$ to take a value 1 rather than 0, unlike $x_0$ and $x_1$. With this idea in mind, if the salesperson has to visit $N+1$ nodes over a route then $N+1$ of the $x_k$ variables must be assigned the value 1. Written as an equation: 

$$ \sum_{k=0}^{N(N+1)-1} x_k = N+1,$$

with $(N(N+1))$ equal to the number of variables used to represent the origin and destination nodes for each trip. You could split the equation for each location vector seperately, but if you keep the constraint linear in $x_k$ the resulting cost function will be the same. To assign a reward to the salesperson for being at a node, the $x_k$ terms are moved to the right side of the equation:

$$ 0 = (N+1) -\left( \sum_{k=0}^{N(N+1)-1} x_k \right).$$

As you may be aware, there is no guarantee which particular $x_k$ the solver will assign the value 1 to in this equation. However, in the previous constraint the salesperson is already enforced to be in a maximum of one node before/after each trip. Therefore with the cost function weights properly tuned, it can be assumed that the salesperson will not be in two or more nodes at once. 

In other words, the previous constraint penalizes the salesperson for being at more than one node at a once, while this constraint rewards them for being at as many nodes before/after any trip (also being in multiple nodes at once). The weights of the constraints will effectively determine how well they are satisfied, a balance between the two needs to be found such that both are adhered to. 

Incorporating this constraint in the code can be done by assigning a negative term to each $x_k$. The $N+1$ value can be ignored, since it results in a linear shift of the optimization landscape and does not have an effect on solutions of the the minimization problem.

```python
    ##### Constraint: Location constraint - encourage the salesperson to be 'somewhere' otherwise all x_k might be 0 (for example).
    # 'gamma' allows us to tune the weights between the penalties 
    Term(
        c = int(-1 * gamma * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
        indices = [v]   
    )
    for v in range((nb_nodes + 1) * nb_nodes) # Select variable (v represents a node before/after any trip)
```
### Constraint 3: Same node constraint - can't travel to the same node more than once (except the starting node)

The salesperson may only visit each node once, meaning that routes containing revisits of a node (other than the starting node) must be penalized. As an example, consider node 3 for each trip (these $x$ describe the same node): 

$$ \text{Node 3:} x_3, x_{3+N}, x_{3+2N}, \dots $$

If the salesperson has been in node 3 after any trip, they may not pass through the same node again. This means that if $x_3$ is 1 for example, $x_{3+N}$ and $x_{3+2N}$ have to be 0. As done similarly with the location constraint, the product of these variables is one way of designing a constraint. As you know that the product between variables representing the same node has to be zero, the following can be derived:

$$ x_3 \cdot x_{3+N} \cdot x_{3+2N} = 0. $$

Even though the equation seems to represent the constraint correctly, it is not stringent enough. With such an equation, if $x_3$ and $x_{3+N}$ are both 1 and $x_{3+2N}$ is 0, the constraint is satisfied with the salesperson having been in the same node twice. Therefore, similarly to the location constraint, more specificity is required. Luckily, the constraint can be split into smaller products:

$$ x_3 \cdot x_{3+N} =0$$
$$ x_3 \cdot x_{3+2N} = 0$$
$$ x_{3+N} \cdot x_{3+2N} = 0$$

Continuing this for all N trips and N nodes yields:

$$ \large{\sum}_{p=0}^{N^2+N-1}\hspace{0.25cm} \large{\sum}_{f=p+N,\hspace{0.2cm} \text{stepsize: } N}^{N^2-1} \hspace{0.35cm} (x_p \cdot x_f) = 0,$$

in which the first summation assigns a reference node $x_p$, and the second summation the same node but after some number of trips $x_f$ (multiple of N: stepsize). 

This constraint penalizes routes in which nodes are visited more than once. It does not include the last trip back to the starting node (headquarters). The last trip does not need to penalized since the salesperson has already visited each node. Therefore, all remaning travels would result in a violation of the constraint. Incorporating it would only make the cost function larger without adding any value to the optimization problem.

```python
    ##### Penalty for traveling to the same node again --- (in the last step we can travel without penalties (this is to make it easier to specify an end node =) ))
    # 'delta' allows us to tune the weights between the penalties 
    Term(
        c = int(delta * max_cost), # assign a weight penalty dependent on maximum distance from the cost matrix elements
        indices = [p, f]   
    )
    for p in range((nb_nodes + 1) * nb_nodes) # This selects a present node x: 'p' for present    
    for f in range(p + nb_nodes, nb_nodes * (nb_nodes), nb_nodes) # This selects the same node x but after upcoming trips: 'f' for future
```

### Constraint 4 & 5: Beginning and ending at a specific node 

The salesperson starts and finishes at the headquarters: the starting node from which they depart on their journey. Similarly to constraint 2, the salesperson can be rewarded for starting/finishing at a specific node.

For example, if you want the salesperson to start/end at a particular node, you can assign negative weights to the respective $x_k$ term in the first and last location vector. For node 0 that would result in negatively weighting $x_0$ and $x_{N^2}$, for example. This constraint is the most flexible one, and you can also expand it to encourage the salesperson to visit a specific node, or nodes, at pre-determined trip number $k$. Alternatively, you may see this constraint as a way to integrate prior-knowledge on the set of nodes into the optimization problem. Let's say you want the salesperson to visit node 1 after the second trip ($k=2$, it is the third node they visit), then by negatively weighting $x_{2N+1}$ the cost function will (likely) obtain a lower/smaller optimal (minimal) value if it gives this variable the value 1. 

In this code, the salesperson is hard-coded to start and finish in node 0.

```python
    ##### Begin at x0
    # 'epsilon' allows us to tune the weights between the penalties 
    Term(
        c = int(-1 * epsilon * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
        indices = [0]   
    ), 
    ##### End at x0
    Term(
        c = int(-1 * epsilon * max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
        indices = [nb_nodes * nb_nodes]   
    )
```

### Submitting the optimization problem

The optimization problem subject to the necessary constraints have been defined! Now it is time hand the problem over to the Azure QIO solvers and analyze the routes that are returned to us. 

Some essential specifications/explanations:

1. The problem type is a [PUBO (Polynomial Unconstrained Binary Optimization)](https://docs.microsoft.com/azure/quantum/optimization-binary-optimization) - the variables ($x_k$) that are optimized for can take a value of 0, or 1.

2. We submit the problem to an Azure QIO solver, which one is up to you. Each has benefits/drawbacks, and [selecting the best one requires some experimentation](https://docs.microsoft.com/azure/quantum/optimization-which-solver-should-you-use). To read more about the available solvers, please refer to the [Microsoft QIO solver overview page](https://docs.microsoft.com/azure/quantum/provider-microsoft-qio) on the Azure Quantum docs site.

3. These optimizers are heuristics, which means they aren't guaranteed to find the optimal solution (or even a valid one, depending on how well you have encoded your cost function). Due to this, it is important to validate the solution returned. It is also recommended to run the solver several times to see if it returns the same solution. Additionally, having longer optimization times (larger timeout) can return better solutions.  

4. The solution returned by the solver is heavily influenced by the constraint weights, which are the `alpha`, `beta`, `gamma`, `delta`, and `epsilon` paramters passed to the `find_route` function. Feel free to play around with these (called tuning), and discover if you can make the optimization more efficient (speed vs solution quality trade-off). A suggestion would be to make the weights dependent on the cost matrix norm (Frobenius,1,2,etc.). 

5. Here the hardware implementation is defaulted to CPU. For further information on available hardware, please refer to the [Microsoft QIO solver overview page](https://docs.microsoft.com/azure/quantum/provider-microsoft-qio) on the Azure Quantum docs site.
