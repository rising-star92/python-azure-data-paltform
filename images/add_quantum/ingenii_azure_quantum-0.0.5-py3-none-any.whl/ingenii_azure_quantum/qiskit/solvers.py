from azure.quantum.qiskit import AzureQuantumProvider
from qiskit.algorithms.optimizers import COBYLA, Optimizer
from qiskit.algorithms import VQE
from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import RealAmplitudes
from qiskit.opflow import CVaRExpectation, PauliExpectation, PauliSumOp, PauliOp
from qiskit.utils import algorithm_globals, QuantumInstance
from qiskit import Aer
from qiskit_nature.algorithms import GroundStateEigensolver, QEOM, VQEUCCFactory
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.problems.second_quantization import BaseProblem
from typing import Union

def get_quantum_instance(
        azure_quantum_provider: AzureQuantumProvider=None,
        azure_backend_name: str=None,
        qiskit_backend: str=None, aer_default: str=None, **kwargs
    ) -> QuantumInstance:
    """
    Find an appropriate quantum instances

    Parameters
    ----------
    azure_quantum_provider : AzureQuantumProvider, optional
        The provider to connect to the Azure Quantum Workspace, by default None
    azure_backend_name : str, optional
        First priority, by default None
    qiskit_backend : str, optional
        Second priority, by default None
    aer_default : str, optional
        Third priority, by default None

    Returns
    -------
    QuantumInstance
        The quantum instance to use
    """
    if azure_backend_name:
        return azure_quantum_provider.get_backend(azure_backend_name)
    else:
        return QuantumInstance(
            qiskit_backend or Aer.get_backend(aer_default),
            **kwargs
        )

def vqe_with_cvar(
        qubit_operator: Union[PauliSumOp, PauliOp],
        optimizer: Optimizer=COBYLA(maxiter=50),
        ansatz: QuantumCircuit=RealAmplitudes(reps=1),
        cvar_alpha: float=0.1,
        azure_quantum_provider: AzureQuantumProvider=None,
        azure_backend_name: Union[str, None]=None,
        qiskit_backend: Union[str, None]=None,
        verbose: bool=False,
    ) -> dict:
    """
    Given the qubit operator, solve using Variational Quantum Eigensolver with
    Conditional Value at Risk (CVaR) expectation values

    Parameters
    ----------
    qubit_operator : Union[PauliSumOp, PauliOp]
        The operator defining a problem to be solved
    optimizer : Optimizer, optional
        The classical optimizer to use, by default COBYLA(maxiter=50)
    ansatz : QuantumCircuit, optional
        The variational ansatz to use, by default RealAmplitudes(reps=1)
    cvar_alpha : float, optional
        The CVaR_alpha objective to use, by default 0.1
    azure_quantum_provider : AzureQuantumProvider, optional
        The provider to connect to the Azure Quantum Workspace, by default None
    azure_backend_name : Union[str, None], optional
        The name of the backend to use in the Azure Quantum workspace, by
        default None. If not set, the qiskit_backend variable is considered 
    qiskit_backend : Union[str, None], optional
        The Qiskit backend to use, by default None. If azure_backend_name is
        not set then this is used; if this is also not set then 'aer_simulator'
        is used as a backend
    verbose: bool, optional
        If set, give more information while solving problem

    Returns
    -------
    dict
        The result returned from the backend
    """

    quantum_instance = get_quantum_instance(
        azure_quantum_provider, azure_backend_name,
        qiskit_backend, "aer_simulator",
        shots=8192,
        seed_transpiler=algorithm_globals.random_seed,
        seed_simulator=algorithm_globals.random_seed,
    )

    # Capture the intermediate results between each Optimizer run
    intermediate_results = []
    def store_intermediate_result(eval_count, parameters, mean, std):
        if verbose:
            print(f"Evaluation count: {eval_count}/{optimizer.settings['options']['maxiter']}")
        intermediate_results.append({
            "count": eval_count,
            "parameters": parameters,
            "mean": mean,
            "standard_deviation": std,
        })

    # Initialize VQE using CVaR
    cvar_exp = CVaRExpectation(cvar_alpha, PauliExpectation())
    vqe = VQE(
        expectation=cvar_exp,
        optimizer=optimizer,
        ansatz=ansatz,
        quantum_instance=quantum_instance,
        callback=store_intermediate_result,
    )

    # Get the result
    result = vqe.compute_minimum_eigenvalue(qubit_operator)

    return {
        "result": result,
        "intermediate_results": intermediate_results
    }

def qeom(
        es_problem: BaseProblem,
        optimizer: Optimizer=COBYLA(maxiter=20),
        qubit_converter: QubitConverter=QubitConverter(JordanWignerMapper()),
        azure_quantum_provider: AzureQuantumProvider=None,
        azure_backend_name: Union[str, None]=None,
        qiskit_backend: Union[str, None]=None,
        verbose: bool=False,
    ) -> dict:
    """
    Solve a problem with the qEOM algorithm [arXiv preprint arXiv:1910.12890 (2019)]

    Parameters
    ----------
    es_problem : BaseProblem
        The problem to solve
    optimizer : Optimizer, optional
        The classical optimizer to use, by default COBYLA(maxiter=20)
    qubit_converter : QubitConverter, optional
        The Qubit converter to understand the problem, by default
        QubitConverter(JordanWignerMapper())
    azure_quantum_provider : AzureQuantumProvider, optional
        The provider to connect to the Azure Quantum Workspace, by default None
    azure_backend_name : Union[str, None], optional
        The name of the backend to use in the Azure Quantum workspace, by
        default None. If not set, the qiskit_backend variable is considered 
    qiskit_backend : Union[str, None], optional
        The Qiskit backend to use, by default None. If azure_backend_name is
        not set then this is used; if this is also not set then
        'aer_simulator_statevector' is used as a backend
    verbose: bool, optional
        If set, give more information while solving problem

    Returns
    -------
    dict
        The result returned from the backend
    """

    quantum_instance = get_quantum_instance(
        azure_quantum_provider, azure_backend_name,
        qiskit_backend, "aer_simulator_statevector",
    )

    # Capture the intermediate results between each Optimizer run
    intermediate_results = []
    def store_intermediate_result(eval_count, parameters, mean, std):
        if verbose:
            print(f"Evaluation count: {eval_count}/{optimizer.settings['options']['maxiter']}")
        intermediate_results.append({
            "count": eval_count,
            "parameters": parameters,
            "mean": mean,
            "standard_deviation": std,
        })

    # This first part sets the ground state solver
    solver = VQEUCCFactory(
        quantum_instance, optimizer, callback=store_intermediate_result)
    gsc = GroundStateEigensolver(qubit_converter, solver)

    # The qEOM algorithm is instantiated with the chosen ground state solver
    qeom_excited_states_calculation = QEOM(gsc, "sd")

    return {
        "result": qeom_excited_states_calculation.solve(es_problem),
        "intermediate_results": intermediate_results
    }
